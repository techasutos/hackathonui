const CACHE_NAME = 'shg-platform-v1';
const urlsToCache = [
  '/',
  '/dashboard',
  '/savings',
  '/loans',
  '/polls',
  '/members',
  '/groups',
  '/sdg-tracking',
  '/csr',
  '/profile',
  '/static/js/bundle.js',
  '/static/css/main.css',
  '/manifest.json'
];

// Install Service Worker
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
  );
});

// Fetch event - serve cached content when offline
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Return cached version or fetch from network
        if (response) {
          return response;
        }
        
        return fetch(event.request).then(response => {
          // Check if valid response
          if (!response || response.status !== 200 || response.type !== 'basic') {
            return response;
          }

          // Clone the response
          const responseToCache = response.clone();

          caches.open(CACHE_NAME)
            .then(cache => {
              cache.put(event.request, responseToCache);
            });

          return response;
        }).catch(() => {
          // Return offline page for navigation requests
          if (event.request.destination === 'document') {
            return caches.match('/offline.html');
          }
        });
      })
  );
});

// Activate Service Worker
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME) {
            console.log('Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// Background Sync for offline data
self.addEventListener('sync', event => {
  if (event.tag === 'background-sync') {
    event.waitUntil(doBackgroundSync());
  }
});

async function doBackgroundSync() {
  try {
    // Sync pending savings deposits
    const pendingSavings = await getFromIndexedDB('pendingSavings');
    for (const saving of pendingSavings) {
      await syncSavingDeposit(saving);
    }

    // Sync pending loan applications
    const pendingLoans = await getFromIndexedDB('pendingLoans');
    for (const loan of pendingLoans) {
      await syncLoanApplication(loan);
    }

    // Sync pending poll votes
    const pendingVotes = await getFromIndexedDB('pendingVotes');
    for (const vote of pendingVotes) {
      await syncPollVote(vote);
    }

    console.log('Background sync completed successfully');
  } catch (error) {
    console.error('Background sync failed:', error);
  }
}

async function syncSavingDeposit(saving) {
  try {
    const response = await fetch('/api/savings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${saving.authToken}`
      },
      body: JSON.stringify(saving.data)
    });

    if (response.ok) {
      await removeFromIndexedDB('pendingSavings', saving.id);
      console.log('Synced saving deposit:', saving.id);
    }
  } catch (error) {
    console.error('Failed to sync saving deposit:', error);
  }
}

async function syncLoanApplication(loan) {
  try {
    const response = await fetch('/api/loans', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${loan.authToken}`
      },
      body: JSON.stringify(loan.data)
    });

    if (response.ok) {
      await removeFromIndexedDB('pendingLoans', loan.id);
      console.log('Synced loan application:', loan.id);
    }
  } catch (error) {
    console.error('Failed to sync loan application:', error);
  }
}

async function syncPollVote(vote) {
  try {
    const response = await fetch(`/api/polls/${vote.pollId}/vote`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${vote.authToken}`
      },
      body: JSON.stringify(vote.data)
    });

    if (response.ok) {
      await removeFromIndexedDB('pendingVotes', vote.id);
      console.log('Synced poll vote:', vote.id);
    }
  } catch (error) {
    console.error('Failed to sync poll vote:', error);
  }
}

// IndexedDB helpers
async function getFromIndexedDB(storeName) {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('SHGPlatformDB', 1);
    
    request.onsuccess = () => {
      const db = request.result;
      const transaction = db.transaction([storeName], 'readonly');
      const store = transaction.objectStore(storeName);
      const getAllRequest = store.getAll();
      
      getAllRequest.onsuccess = () => {
        resolve(getAllRequest.result || []);
      };
      
      getAllRequest.onerror = () => {
        reject(getAllRequest.error);
      };
    };
    
    request.onerror = () => {
      reject(request.error);
    };
  });
}

async function removeFromIndexedDB(storeName, id) {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('SHGPlatformDB', 1);
    
    request.onsuccess = () => {
      const db = request.result;
      const transaction = db.transaction([storeName], 'readwrite');
      const store = transaction.objectStore(storeName);
      const deleteRequest = store.delete(id);
      
      deleteRequest.onsuccess = () => {
        resolve();
      };
      
      deleteRequest.onerror = () => {
        reject(deleteRequest.error);
      };
    };
    
    request.onerror = () => {
      reject(request.error);
    };
  });
}

// Push notification handling
self.addEventListener('push', event => {
  const data = event.data ? event.data.json() : {};
  const title = data.title || 'SHG Platform Notification';
  const options = {
    body: data.body || 'You have a new notification',
    icon: '/icons/icon-192x192.png',
    badge: '/icons/icon-72x72.png',
    tag: data.tag || 'general',
    data: data.url || '/',
    requireInteraction: true,
    actions: [
      {
        action: 'open',
        title: 'Open',
        icon: '/icons/icon-72x72.png'
      },
      {
        action: 'dismiss',
        title: 'Dismiss'
      }
    ]
  };

  event.waitUntil(
    self.registration.showNotification(title, options)
  );
});

// Handle notification clicks
self.addEventListener('notificationclick', event => {
  event.notification.close();

  if (event.action === 'open' || !event.action) {
    event.waitUntil(
      clients.openWindow(event.notification.data || '/')
    );
  }
});