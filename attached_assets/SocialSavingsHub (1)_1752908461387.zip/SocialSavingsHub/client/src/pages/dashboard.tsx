import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { AuthGuard } from "@/components/auth/auth-guard";
import { MetricsCard } from "@/components/dashboard/metrics-card";
import { ChartContainer } from "@/components/dashboard/chart-container";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  PiggyBank,
  CreditCard,
  Users,
  Globe,
  TrendingUp,
  Download,
} from "lucide-react";
import { DashboardStats } from "@/types/api";

export default function Dashboard() {
  const { member } = useAuth();
  
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/dashboard/stats", member?.groupId],
    enabled: !!member?.groupId,
  });

  // Mock data for charts - in real app, this would come from API
  const savingsData = [
    { name: "Jan", value: 15000 },
    { name: "Feb", value: 18000 },
    { name: "Mar", value: 22000 },
    { name: "Apr", value: 25000 },
    { name: "May", value: 30000 },
    { name: "Jun", value: 35000 },
  ];

  const loanDistribution = [
    { name: "Business", value: 40 },
    { name: "Education", value: 25 },
    { name: "Healthcare", value: 20 },
    { name: "Agriculture", value: 15 },
  ];

  const sdgProgress = [
    { name: "SDG 1", value: 75 },
    { name: "SDG 5", value: 90 },
    { name: "SDG 8", value: 65 },
    { name: "SDG 10", value: 80 },
  ];

  if (isLoading) {
    return (
      <AuthGuard>
        <div className="container mx-auto py-8 px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-32 bg-muted animate-pulse rounded-lg"></div>
            ))}
          </div>
        </div>
      </AuthGuard>
    );
  }

  const dashboardStats = stats as DashboardStats;

  return (
    <AuthGuard>
      <div className="container mx-auto py-8 px-4 space-y-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold">Dashboard</h1>
            <p className="text-muted-foreground">
              Welcome back! Here's what's happening with your group.
            </p>
          </div>
          <Button>
            <Download className="mr-2 h-4 w-4" />
            Export Reports
          </Button>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricsCard
            title="Total Savings"
            value={`₹${dashboardStats?.totalSavings?.toLocaleString() || "0"}`}
            subtitle="+12% from last month"
            icon={PiggyBank}
            trend={{ value: 12, label: "from last month", isPositive: true }}
          />
          
          <MetricsCard
            title="Active Loans"
            value={`₹${dashboardStats?.totalLoanAmount?.toLocaleString() || "0"}`}
            subtitle={`${dashboardStats?.memberCount || 0} active loans`}
            icon={CreditCard}
          />
          
          <MetricsCard
            title="Group Members"
            value={dashboardStats?.memberCount || 0}
            subtitle={`${dashboardStats?.pendingApprovals || 0} pending approvals`}
            icon={Users}
          />
          
          <MetricsCard
            title="SDG Impact Score"
            value={`${dashboardStats?.sdgScore || 0}%`}
            subtitle={`Across ${dashboardStats?.sdgGoalsImpacted || 0} SDG goals`}
            icon={Globe}
            trend={{ value: 5, label: "this quarter", isPositive: true }}
          />
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ChartContainer
            title="Savings Growth Trend"
            type="line"
            data={savingsData}
            dataKey="value"
            xAxisKey="name"
          />
          
          <ChartContainer
            title="Loan Distribution by Purpose"
            type="pie"
            data={loanDistribution}
            dataKey="value"
          />
        </div>

        {/* Additional Info */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Recent Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm">New member joined</span>
                  <span className="text-xs text-muted-foreground">2 hours ago</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Loan approved</span>
                  <span className="text-xs text-muted-foreground">1 day ago</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Savings deposited</span>
                  <span className="text-xs text-muted-foreground">2 days ago</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Group Balance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                ₹{dashboardStats?.groupBalance?.toLocaleString() || "0"}
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                Total available funds
              </p>
            </CardContent>
          </Card>

          <ChartContainer
            title="SDG Impact Progress"
            type="bar"
            data={sdgProgress}
            dataKey="value"
            xAxisKey="name"
            className="lg:col-span-1"
          />
        </div>
      </div>
    </AuthGuard>
  );
}
