import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { AuthGuard } from "@/components/auth/auth-guard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { LoanApplicationForm } from "@/components/loans/loan-application-form";
import { Plus, Eye, CheckCircle, XCircle } from "lucide-react";
import { LoanApplication } from "@shared/schema";
import { hasRole } from "@/lib/auth";

export default function Loans() {
  const { member } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const { data: loans, isLoading } = useQuery({
    queryKey: ["/api/loans", { groupId: member?.groupId }],
    enabled: !!member?.groupId,
  });

  const updateLoanMutation = useMutation({
    mutationFn: async ({ loanId, status }: { loanId: number; status: string }) => {
      const response = await apiRequest("PUT", `/api/loans/${loanId}`, { status });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/loans"] });
      toast({
        title: "Success",
        description: "Loan status updated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update loan status",
        variant: "destructive",
      });
    },
  });

  const getStatusBadge = (status: string) => {
    const variants = {
      PENDING: "secondary",
      APPROVED: "default",
      DISBURSED: "default",
      REPAID: "default",
      REJECTED: "destructive",
    } as const;

    return (
      <Badge variant={variants[status as keyof typeof variants] || "secondary"}>
        {status}
      </Badge>
    );
  };

  const canApprove = hasRole(["ADMIN", "PRESIDENT"]);
  const canDisburse = hasRole(["ADMIN", "TREASURER"]);

  if (isLoading) {
    return (
      <AuthGuard>
        <div className="container mx-auto py-8 px-4">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-muted rounded w-1/4"></div>
            <div className="h-64 bg-muted rounded"></div>
          </div>
        </div>
      </AuthGuard>
    );
  }

  return (
    <AuthGuard>
      <div className="container mx-auto py-8 px-4 space-y-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold">Loan Management</h1>
            <p className="text-muted-foreground">
              Manage loan applications, approvals, and repayments
            </p>
          </div>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Apply for Loan
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>New Loan Application</DialogTitle>
              </DialogHeader>
              <LoanApplicationForm onSuccess={() => setIsDialogOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>

        {/* Loans Table */}
        <Card>
          <CardHeader>
            <CardTitle>Loan Applications</CardTitle>
          </CardHeader>
          <CardContent>
            {!loans || loans.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No loan applications found</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Application ID</TableHead>
                      <TableHead>Member</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Purpose</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Applied Date</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loans?.map((loan: LoanApplication) => (
                      <TableRow key={loan.id}>
                        <TableCell className="font-medium">
                          LA-{loan.id.toString().padStart(4, '0')}
                        </TableCell>
                        <TableCell>Member {loan.memberId}</TableCell>
                        <TableCell>₹{parseFloat(loan.amount).toLocaleString()}</TableCell>
                        <TableCell className="capitalize">{loan.purpose}</TableCell>
                        <TableCell>{getStatusBadge(loan.status)}</TableCell>
                        <TableCell>
                          {new Date(loan.appliedAt).toLocaleDateString()}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              <Eye className="h-4 w-4" />
                            </Button>
                            
                            {loan.status === "PENDING" && canApprove && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() =>
                                  updateLoanMutation.mutate({
                                    loanId: loan.id,
                                    status: "APPROVED",
                                  })
                                }
                                disabled={updateLoanMutation.isPending}
                              >
                                <CheckCircle className="h-4 w-4 text-green-600" />
                              </Button>
                            )}
                            
                            {loan.status === "APPROVED" && canDisburse && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() =>
                                  updateLoanMutation.mutate({
                                    loanId: loan.id,
                                    status: "DISBURSED",
                                  })
                                }
                                disabled={updateLoanMutation.isPending}
                              >
                                Disburse
                              </Button>
                            )}
                            
                            {loan.status === "PENDING" && canApprove && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() =>
                                  updateLoanMutation.mutate({
                                    loanId: loan.id,
                                    status: "REJECTED",
                                  })
                                }
                                disabled={updateLoanMutation.isPending}
                              >
                                <XCircle className="h-4 w-4 text-red-600" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AuthGuard>
  );
}
