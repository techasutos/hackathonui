import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { AuthGuard } from "@/components/auth/auth-guard";
import { MetricsCard } from "@/components/dashboard/metrics-card";
import { ChartContainer } from "@/components/dashboard/chart-container";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { SDGGoalCard } from "@/components/sdg/sdg-goal-card";
import { Globe, Users, Briefcase, TrendingUp } from "lucide-react";
import { SDGImpact } from "@shared/schema";

export default function SDGTracking() {
  const { member } = useAuth();

  const { data: sdgImpacts, isLoading } = useQuery({
    queryKey: ["/api/sdg/impact", member?.groupId],
    enabled: !!member?.groupId,
  });

  const sdgGoals = [
    { number: 1, title: "No Poverty", color: "#e74c3c", description: "End poverty in all its forms everywhere" },
    { number: 2, title: "Zero Hunger", color: "#dda63a", description: "End hunger, achieve food security and improved nutrition" },
    { number: 3, title: "Good Health", color: "#4c9f38", description: "Ensure healthy lives and promote well-being for all" },
    { number: 4, title: "Quality Education", color: "#c5192d", description: "Ensure inclusive and equitable quality education" },
    { number: 5, title: "Gender Equality", color: "#ff3a21", description: "Achieve gender equality and empower all women and girls" },
    { number: 6, title: "Clean Water", color: "#26bde2", description: "Ensure availability and sustainable management of water" },
    { number: 7, title: "Affordable Energy", color: "#fcc30b", description: "Ensure access to affordable, reliable, sustainable energy" },
    { number: 8, title: "Decent Work", color: "#a21942", description: "Promote sustained, inclusive economic growth and employment" },
    { number: 9, title: "Innovation", color: "#fd6925", description: "Build resilient infrastructure, promote inclusive industrialization" },
    { number: 10, title: "Reduced Inequalities", color: "#dd1367", description: "Reduce inequality within and among countries" },
    { number: 11, title: "Sustainable Cities", color: "#fd9d24", description: "Make cities and human settlements inclusive, safe, resilient" },
    { number: 12, title: "Responsible Consumption", color: "#bf8b2e", description: "Ensure sustainable consumption and production patterns" },
    { number: 13, title: "Climate Action", color: "#3f7e44", description: "Take urgent action to combat climate change" },
    { number: 14, title: "Life Below Water", color: "#0a97d9", description: "Conserve and sustainably use the oceans, seas" },
    { number: 15, title: "Life on Land", color: "#56c02b", description: "Protect, restore and promote sustainable use of terrestrial ecosystems" },
    { number: 16, title: "Peace and Justice", color: "#00689d", description: "Promote peaceful and inclusive societies for sustainable development" },
    { number: 17, title: "Partnerships", color: "#19486a", description: "Strengthen the means of implementation and revitalize partnerships" },
  ];

  const impactData = sdgImpacts || [];
  const totalJobsCreated = impactData.reduce((sum: number, impact: SDGImpact) => sum + impact.jobsCreated, 0);
  const totalWomenEmpowered = impactData.reduce((sum: number, impact: SDGImpact) => sum + impact.womenEmpowered, 0);
  const avgImpactScore = impactData.length > 0 
    ? Math.round(impactData.reduce((sum: number, impact: SDGImpact) => sum + impact.impactScore, 0) / impactData.length)
    : 0;

  const chartData = impactData.map((impact: SDGImpact) => ({
    name: `SDG ${impact.goalNumber}`,
    value: impact.impactScore,
  }));

  if (isLoading) {
    return (
      <AuthGuard>
        <div className="container mx-auto py-8 px-4">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-muted rounded w-1/4"></div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-32 bg-muted rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </AuthGuard>
    );
  }

  return (
    <AuthGuard>
      <div className="container mx-auto py-8 px-4 space-y-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-4">SDG Impact Tracking</h1>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Track how our Self Help Group activities contribute to the United Nations Sustainable Development Goals and measure our social impact.
          </p>
        </div>

        {/* Hero Card */}
        <Card className="bg-gradient-to-br from-green-50 to-blue-50 border-green-200">
          <CardContent className="p-8 text-center">
            <Globe className="h-16 w-16 text-green-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Sustainable Development Goals Impact</h2>
            <p className="text-muted-foreground">
              Empowering communities and creating lasting change through our financial inclusion initiatives
            </p>
          </CardContent>
        </Card>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <MetricsCard
            title="Goals Impacted"
            value={`${impactData.length}/17`}
            subtitle="SDG Goals actively supported"
            icon={Globe}
          />
          
          <MetricsCard
            title="Women Empowered"
            value={totalWomenEmpowered}
            subtitle="Direct beneficiaries"
            icon={Users}
          />
          
          <MetricsCard
            title="Jobs Created"
            value={totalJobsCreated}
            subtitle="Through micro-enterprises"
            icon={Briefcase}
          />
        </div>

        {/* Impact Chart */}
        {chartData.length > 0 && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <ChartContainer
              title="SDG Impact Scores"
              type="bar"
              data={chartData}
              dataKey="value"
              xAxisKey="name"
            />
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Overall Impact Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">
                    {avgImpactScore}%
                  </div>
                  <p className="text-muted-foreground">Average Impact Score</p>
                </div>
                
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm">Community Development</span>
                    <span className="text-sm font-medium">85%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Economic Empowerment</span>
                    <span className="text-sm font-medium">78%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Gender Equality</span>
                    <span className="text-sm font-medium">92%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* SDG Goals Grid */}
        <div>
          <h2 className="text-2xl font-bold mb-6">All Sustainable Development Goals</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {sdgGoals.map((goal) => {
              const impact = impactData.find((impact: SDGImpact) => impact.goalNumber === goal.number);
              return (
                <SDGGoalCard
                  key={goal.number}
                  goal={goal}
                  impact={impact}
                />
              );
            })}
          </div>
        </div>
      </div>
    </AuthGuard>
  );
}
