import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { AuthGuard } from "@/components/auth/auth-guard";
import { MetricsCard } from "@/components/dashboard/metrics-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { hasRole } from "@/lib/auth";
import { Building, Users, TrendingUp, Calendar, Plus, Eye } from "lucide-react";
import { Group } from "@shared/schema";

export default function Groups() {
  const { member } = useAuth();

  const { data: groups, isLoading } = useQuery({
    queryKey: ["/api/groups"],
  });

  const { data: currentGroup } = useQuery({
    queryKey: ["/api/groups", member?.groupId],
    enabled: !!member?.groupId,
  });

  const canManageGroups = hasRole(["ADMIN"]);

  if (isLoading) {
    return (
      <AuthGuard>
        <div className="container mx-auto py-8 px-4">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-muted rounded w-1/4"></div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-32 bg-muted rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </AuthGuard>
    );
  }

  return (
    <AuthGuard>
      <div className="container mx-auto py-8 px-4 space-y-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold">Group Management</h1>
            <p className="text-muted-foreground">
              Manage Self Help Groups and monitor their performance
            </p>
          </div>
          
          {canManageGroups && (
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Create Group
            </Button>
          )}
        </div>

        {/* Current Group Overview */}
        {currentGroup && (
          <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building className="h-5 w-5" />
                My Group: {currentGroup.name}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    ₹{parseFloat(currentGroup.totalBalance).toLocaleString()}
                  </div>
                  <p className="text-sm text-muted-foreground">Total Balance</p>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    ₹{parseFloat(currentGroup.totalProfit).toLocaleString()}
                  </div>
                  <p className="text-sm text-muted-foreground">Total Profit</p>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-600">
                    ₹{parseFloat(currentGroup.totalLoss).toLocaleString()}
                  </div>
                  <p className="text-sm text-muted-foreground">Total Loss</p>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">
                    {new Date(currentGroup.createdAt).getFullYear()}
                  </div>
                  <p className="text-sm text-muted-foreground">Established</p>
                </div>
              </div>
              
              {currentGroup.description && (
                <div className="mt-4 p-4 bg-white/50 rounded-lg">
                  <p className="text-sm">{currentGroup.description}</p>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Group Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <MetricsCard
            title="Total Groups"
            value={groups?.length || 0}
            subtitle="Active SHG groups"
            icon={Building}
          />
          
          <MetricsCard
            title="Average Members"
            value="15"
            subtitle="Per group"
            icon={Users}
          />
          
          <MetricsCard
            title="Growth Rate"
            value="+12%"
            subtitle="This quarter"
            icon={TrendingUp}
            trend={{ value: 12, label: "this quarter", isPositive: true }}
          />
        </div>

        {/* Groups List */}
        <Card>
          <CardHeader>
            <CardTitle>All Groups</CardTitle>
          </CardHeader>
          <CardContent>
            {!groups || groups.length === 0 ? (
              <div className="text-center py-8">
                <Building className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium">No groups found</h3>
                <p className="text-muted-foreground">
                  No Self Help Groups have been created yet
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {groups.map((group: Group) => (
                  <Card key={group.id} className="hover:shadow-md transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <CardTitle className="text-lg">{group.name}</CardTitle>
                        <Badge variant="outline">
                          Active
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="text-sm text-muted-foreground">
                        {group.description || "No description available"}
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="font-medium">Balance:</span>
                          <div className="text-green-600 font-semibold">
                            ₹{parseFloat(group.totalBalance).toLocaleString()}
                          </div>
                        </div>
                        <div>
                          <span className="font-medium">Profit:</span>
                          <div className="text-blue-600 font-semibold">
                            ₹{parseFloat(group.totalProfit).toLocaleString()}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4" />
                        Created {new Date(group.createdAt).toLocaleDateString()}
                      </div>

                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <Eye className="mr-2 h-4 w-4" />
                          View Details
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AuthGuard>
  );
}
