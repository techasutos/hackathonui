import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { AuthGuard } from "@/components/auth/auth-guard";
import { MetricsCard } from "@/components/dashboard/metrics-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { PollItem } from "@/components/polls/poll-item";
import { CreatePollForm } from "@/components/polls/create-poll-form";
import { hasRole } from "@/lib/auth";
import { Vote, Plus, CheckCircle, Clock } from "lucide-react";
import { Poll } from "@shared/schema";

export default function Polls() {
  const { member } = useAuth();
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const { data: polls, isLoading } = useQuery({
    queryKey: ["/api/polls", { groupId: member?.groupId }],
    enabled: !!member?.groupId,
  });

  const activePolls = polls?.filter((poll: Poll) => poll.isActive) || [];
  const closedPolls = polls?.filter((poll: Poll) => !poll.isActive) || [];

  const canCreatePolls = hasRole(["ADMIN", "PRESIDENT"]);

  if (isLoading) {
    return (
      <AuthGuard>
        <div className="container mx-auto py-8 px-4">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-muted rounded w-1/4"></div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-32 bg-muted rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </AuthGuard>
    );
  }

  return (
    <AuthGuard>
      <div className="container mx-auto py-8 px-4 space-y-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold">Governance & Polls</h1>
            <p className="text-muted-foreground">
              Participate in group decisions through transparent voting
            </p>
          </div>
          
          {canCreatePolls && (
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Create Poll
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Create New Poll</DialogTitle>
                </DialogHeader>
                <CreatePollForm onSuccess={() => setIsDialogOpen(false)} />
              </DialogContent>
            </Dialog>
          )}
        </div>

        {/* Hero Card */}
        <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200">
          <CardContent className="p-8 text-center">
            <Vote className="h-16 w-16 text-blue-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Democratic Governance</h2>
            <p className="text-muted-foreground">
              Every voice matters. Participate in group decisions and help shape the future of our community.
            </p>
          </CardContent>
        </Card>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <MetricsCard
            title="Active Polls"
            value={activePolls.length}
            subtitle="Currently open for voting"
            icon={Vote}
          />
          
          <MetricsCard
            title="My Participation"
            value="95%"
            subtitle="Voting participation rate"
            icon={CheckCircle}
          />
          
          <MetricsCard
            title="Completed Polls"
            value={closedPolls.length}
            subtitle="Total decisions made"
            icon={Clock}
          />
        </div>

        {/* Active Polls */}
        {activePolls.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Active Polls</h2>
            <div className="space-y-6">
              {activePolls.map((poll: Poll) => (
                <PollItem key={poll.id} poll={poll} />
              ))}
            </div>
          </div>
        )}

        {/* Recent Decisions */}
        {closedPolls.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Recent Decisions</h2>
            <div className="space-y-6">
              {closedPolls.slice(0, 5).map((poll: Poll) => (
                <PollItem key={poll.id} poll={poll} showResults={true} />
              ))}
            </div>
          </div>
        )}

        {/* Empty State */}
        {polls && polls.length === 0 && (
          <Card>
            <CardContent className="text-center py-12">
              <Vote className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No Polls Yet</h3>
              <p className="text-muted-foreground mb-6">
                No polls have been created for this group. 
                {canCreatePolls && " Create the first poll to start democratic decision making."}
              </p>
              {canCreatePolls && (
                <Button onClick={() => setIsDialogOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Create First Poll
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </AuthGuard>
  );
}
