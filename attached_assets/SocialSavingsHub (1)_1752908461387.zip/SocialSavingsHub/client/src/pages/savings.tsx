import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { AuthGuard } from "@/components/auth/auth-guard";
import { MetricsCard } from "@/components/dashboard/metrics-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { DepositForm } from "@/components/savings/deposit-form";
import { Plus, PiggyBank, Target, TrendingUp, Download } from "lucide-react";
import { SavingDeposit } from "@shared/schema";

export default function Savings() {
  const { member } = useAuth();
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const { data: deposits, isLoading } = useQuery({
    queryKey: ["/api/savings", { memberId: member?.id }],
    enabled: !!member?.id,
  });

  const { data: groupDeposits } = useQuery({
    queryKey: ["/api/savings", { groupId: member?.groupId }],
    enabled: !!member?.groupId,
  });

  const myTotalSavings = deposits?.reduce((sum: number, deposit: SavingDeposit) => 
    sum + parseFloat(deposit.amount), 0) || 0;
  
  const groupTotalSavings = groupDeposits?.reduce((sum: number, deposit: SavingDeposit) => 
    sum + parseFloat(deposit.amount), 0) || 0;

  const monthlyTarget = 500;
  const currentMonth = new Date().getMonth();
  const thisMonthDeposits = deposits?.filter((deposit: SavingDeposit) => 
    new Date(deposit.depositDate).getMonth() === currentMonth
  ) || [];
  const thisMonthTotal = thisMonthDeposits.reduce((sum: number, deposit: SavingDeposit) => 
    sum + parseFloat(deposit.amount), 0);
  const targetProgress = Math.min((thisMonthTotal / monthlyTarget) * 100, 100);

  if (isLoading) {
    return (
      <AuthGuard>
        <div className="container mx-auto py-8 px-4">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-muted rounded w-1/4"></div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-32 bg-muted rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </AuthGuard>
    );
  }

  return (
    <AuthGuard>
      <div className="container mx-auto py-8 px-4 space-y-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold">Savings Management</h1>
            <p className="text-muted-foreground">
              Track your savings deposits and monitor group progress
            </p>
          </div>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Make Deposit
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>New Savings Deposit</DialogTitle>
              </DialogHeader>
              <DepositForm onSuccess={() => setIsDialogOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <MetricsCard
            title="My Total Savings"
            value={`₹${myTotalSavings.toLocaleString()}`}
            subtitle={`Last deposit: ${deposits?.length ? new Date(deposits[0].depositDate).toLocaleDateString() : 'N/A'}`}
            icon={PiggyBank}
            className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200"
          />
          
          <MetricsCard
            title="Group Savings"
            value={`₹${groupTotalSavings.toLocaleString()}`}
            subtitle="Total group fund"
            icon={TrendingUp}
          />
          
          <MetricsCard
            title="Monthly Target"
            value={`₹${monthlyTarget}`}
            subtitle={`Progress: ${targetProgress.toFixed(0)}%`}
            icon={Target}
            trend={{
              value: targetProgress,
              label: "of target achieved",
              isPositive: targetProgress >= 100,
            }}
          />
        </div>

        {/* Progress Card */}
        <Card>
          <CardHeader>
            <CardTitle>Monthly Savings Progress</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between text-sm">
                <span>This Month: ₹{thisMonthTotal}</span>
                <span>Target: ₹{monthlyTarget}</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div
                  className="bg-primary h-2 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(targetProgress, 100)}%` }}
                ></div>
              </div>
              <div className="text-sm text-muted-foreground">
                {targetProgress >= 100 
                  ? "🎉 Congratulations! You've achieved your monthly target!" 
                  : `₹${monthlyTarget - thisMonthTotal} more needed to reach your target`
                }
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Deposits Table */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Recent Deposits</CardTitle>
            <Button variant="outline" size="sm">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </CardHeader>
          <CardContent>
            {!deposits || deposits.length === 0 ? (
              <div className="text-center py-8">
                <PiggyBank className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium">No deposits yet</h3>
                <p className="text-muted-foreground">
                  Start your savings journey by making your first deposit
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Remarks</TableHead>
                      <TableHead>Receipt</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {deposits.map((deposit: SavingDeposit) => (
                      <TableRow key={deposit.id}>
                        <TableCell>
                          {new Date(deposit.depositDate).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="font-medium">
                          ₹{parseFloat(deposit.amount).toLocaleString()}
                        </TableCell>
                        <TableCell>
                          {deposit.remarks || "Regular savings"}
                        </TableCell>
                        <TableCell>
                          <Button variant="outline" size="sm">
                            <Download className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AuthGuard>
  );
}
