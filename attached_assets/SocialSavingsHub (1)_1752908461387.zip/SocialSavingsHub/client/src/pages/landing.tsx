import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { MetricsCard } from "@/components/dashboard/metrics-card";
import {
  PiggyBank,
  HandHeart,
  Vote,
  Globe,
  TrendingUp,
  Users,
  ArrowRight,
  CheckCircle,
  Target,
  Shield,
  Star,
  Quote,
  Phone,
  Mail,
  MapPin,
  Facebook,
  Twitter,
  Instagram,
  Linkedin,
  Download,
  Wifi,
  BarChart3,
  MessageSquare,
} from "lucide-react";

export default function Landing() {
  const features = [
    {
      icon: PiggyBank,
      title: "Digital Savings Management",
      description: "Track individual and group savings with automated calculations, monthly summaries, and export capabilities for transparent financial management.",
    },
    {
      icon: HandHeart,
      title: "Smart Loan Processing",
      description: "Streamlined loan application, approval workflow with role-based permissions, and automated repayment tracking for efficient fund utilization.",
    },
    {
      icon: Vote,
      title: "Governance & Polling",
      description: "Digital voting system for group decisions, meeting attendance tracking, and transparent governance with audit trails for accountability.",
    },
    {
      icon: Globe,
      title: "SDG Impact Tracking",
      description: "Automatic mapping of activities to Sustainable Development Goals with impact analytics, progress monitoring, and compliance reporting.",
    },
    {
      icon: TrendingUp,
      title: "Financial Analytics",
      description: "Real-time profit/loss tracking, fund utilization analytics, and comprehensive reporting with visual dashboards for informed decision making.",
    },
    {
      icon: Users,
      title: "Member Management",
      description: "Complete member onboarding with approval workflows, role-based access control, and profile management for secure group operations.",
    },
  ];

  const stats = [
    { title: "Active SHG Groups", value: "1000+", subtitle: "Across rural India" },
    { title: "Total Savings Managed", value: "₹50L+", subtitle: "Cumulative funds" },
    { title: "Women Empowered", value: "5000+", subtitle: "Direct beneficiaries" },
    { title: "SDG Goals Aligned", value: "17", subtitle: "Comprehensive impact" },
  ];

  const testimonials = [
    {
      name: "Priya Sharma",
      role: "SHG President, Rajasthan",
      image: "👩‍🌾",
      quote: "SHG Digital Platform has transformed our group management. We can now track every rupee, ensure transparency, and our loan processing is 10x faster. The SDG tracking helps us show our impact to donors.",
      rating: 5
    },
    {
      name: "Meera Devi",
      role: "Group Treasurer, Bihar",
      image: "👩‍🏫",
      quote: "The mobile app works perfectly even with our slow internet. We can manage savings offline and sync when connected. Our members love the transparency and can check their savings anytime.",
      rating: 5
    },
    {
      name: "Sunita Singh",
      role: "Member, Uttar Pradesh",
      image: "👩‍⚕️",
      quote: "Getting loans is now so simple! The voting system helps our group make democratic decisions. I started my small business with a loan processed through this platform in just 3 days.",
      rating: 5
    }
  ];

  const newFeatures = [
    {
      icon: Download,
      title: "Offline-First PWA",
      description: "Works without internet connection. Automatically syncs data when online. Install as mobile app for better experience."
    },
    {
      icon: BarChart3,
      title: "Advanced Reporting",
      description: "Custom dashboard creation with drag-drop widgets. Export reports in multiple formats. Real-time analytics and insights."
    },
    {
      icon: MessageSquare,
      title: "SMS/WhatsApp Integration",
      description: "Automated notifications for loan approvals, meeting reminders, and payment alerts. Multi-language support for regional languages."
    },
    {
      icon: Globe,
      title: "Multi-Language Support",
      description: "Available in Hindi, Bengali, Tamil, Telugu, Marathi, and 10+ regional languages. Seamless language switching for better accessibility."
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="hero-gradient text-white py-20 md:py-32">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
            Empowering Rural Communities Through Digital Savings
          </h1>
          <p className="text-lg md:text-xl mb-8 opacity-90 max-w-3xl mx-auto">
            A comprehensive platform for Self Help Groups to manage savings, loans, and community development initiatives aligned with SDG goals.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/login">
              <Button size="lg" className="bg-white text-primary hover:bg-gray-100 px-8 py-6 text-lg font-semibold rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
                <Target className="mr-3 h-6 w-6" />
                Start Your Journey
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
              <CheckCircle className="mr-2 h-5 w-5" />
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-card">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">
                  {stat.value}
                </div>
                <div className="font-medium text-foreground mb-1">{stat.title}</div>
                <div className="text-sm text-muted-foreground">{stat.subtitle}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Core Platform Features
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Comprehensive tools designed specifically for Self Help Groups to manage their financial activities and track their social impact.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="group hover:shadow-lg transition-all duration-200">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Advanced Features Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Advanced Capabilities
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Cutting-edge features designed for modern SHG management with offline capabilities, automation, and multi-language support.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {newFeatures.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="group hover:shadow-lg transition-all duration-200 border-2 hover:border-primary/20">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 bg-gradient-to-br from-primary/20 to-primary/5 rounded-xl flex items-center justify-center mb-4 mx-auto group-hover:from-primary/30 group-hover:to-primary/10 transition-all">
                      <Icon className="h-8 w-8 text-primary" />
                    </div>
                    <h3 className="text-lg font-semibold mb-3">{feature.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* SVG Illustration Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold mb-6">
                  Empowering Rural Women Through Technology
                </h2>
                <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                  Our platform bridges the digital divide by providing intuitive tools that work in low-connectivity environments, helping rural women manage their finances, access credit, and build sustainable livelihoods.
                </p>
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                    <span>Works offline and syncs automatically</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                    <span>Available in 10+ regional languages</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                    <span>SMS notifications for non-smartphone users</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                    <span>Real-time impact tracking and reporting</span>
                  </div>
                </div>
              </div>
              <div className="relative">
                {/* SVG Illustration */}
                <svg viewBox="0 0 400 300" className="w-full h-auto">
                  {/* Sky background */}
                  <defs>
                    <linearGradient id="skyGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#87CEEB" />
                      <stop offset="100%" stopColor="#98FB98" />
                    </linearGradient>
                  </defs>
                  <rect width="400" height="300" fill="url(#skyGradient)" />
                  
                  {/* Mountains */}
                  <polygon points="0,200 100,150 200,180 400,160 400,300 0,300" fill="#8FBC8F" />
                  
                  {/* Village houses */}
                  <rect x="50" y="180" width="40" height="30" fill="#D2691E" />
                  <polygon points="50,180 70,160 90,180" fill="#8B4513" />
                  <rect x="55" y="190" width="8" height="12" fill="#654321" />
                  <rect x="75" y="185" width="6" height="6" fill="#FFD700" />
                  
                  <rect x="120" y="185" width="35" height="25" fill="#D2691E" />
                  <polygon points="120,185 137.5,170 155,185" fill="#8B4513" />
                  <rect x="125" y="195" width="6" height="10" fill="#654321" />
                  
                  {/* Women figures */}
                  <g transform="translate(200,200)">
                    {/* Woman 1 with sari */}
                    <circle cx="0" cy="-10" r="8" fill="#F4A460" />
                    <rect x="-5" y="-2" width="10" height="15" fill="#FF69B4" rx="2" />
                    <rect x="-3" y="13" width="6" height="8" fill="#8B4513" />
                    <circle cx="-12" cy="5" r="3" fill="#32CD32" /> {/* Pot */}
                  </g>
                  
                  <g transform="translate(250,205)">
                    {/* Woman 2 with phone */}
                    <circle cx="0" cy="-10" r="8" fill="#DEB887" />
                    <rect x="-5" y="-2" width="10" height="15" fill="#4169E1" rx="2" />
                    <rect x="-3" y="13" width="6" height="8" fill="#8B4513" />
                    <rect x="8" y="-5" width="4" height="6" fill="#000" rx="1" /> {/* Phone */}
                  </g>
                  
                  <g transform="translate(300,210)">
                    {/* Woman 3 with basket */}
                    <circle cx="0" cy="-10" r="8" fill="#CD853F" />
                    <rect x="-5" y="-2" width="10" height="15" fill="#228B22" rx="2" />
                    <rect x="-3" y="13" width="6" height="8" fill="#8B4513" />
                    <ellipse cx="-15" cy="0" rx="6" ry="4" fill="#DEB887" /> {/* Basket */}
                  </g>
                  
                  {/* Trees */}
                  <circle cx="30" cy="160" r="15" fill="#228B22" />
                  <rect x="27" y="175" width="6" height="20" fill="#8B4513" />
                  
                  <circle cx="350" cy="140" r="20" fill="#228B22" />
                  <rect x="346" y="160" width="8" height="25" fill="#8B4513" />
                  
                  {/* Sun */}
                  <circle cx="350" cy="50" r="20" fill="#FFD700" />
                  
                  {/* Digital elements overlay */}
                  <rect x="180" y="120" width="80" height="50" fill="rgba(255,255,255,0.9)" rx="10" stroke="#4169E1" strokeWidth="2" />
                  <text x="220" y="140" textAnchor="middle" fontSize="8" fill="#4169E1" fontWeight="bold">SHG Digital</text>
                  <text x="220" y="150" textAnchor="middle" fontSize="6" fill="#4169E1">Platform</text>
                  <circle cx="200" cy="155" r="3" fill="#32CD32" />
                  <circle cx="220" cy="155" r="3" fill="#FFD700" />
                  <circle cx="240" cy="155" r="3" fill="#FF69B4" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gradient-to-br from-primary/5 to-primary/10">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              What Our Community Says
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Real stories from SHG members across India who have transformed their lives using our platform.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-center gap-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <Quote className="h-8 w-8 text-primary/30 mb-4" />
                  <p className="text-muted-foreground mb-6 leading-relaxed italic">
                    "{testimonial.quote}"
                  </p>
                  <div className="flex items-center gap-3">
                    <div className="text-3xl">{testimonial.image}</div>
                    <div>
                      <div className="font-semibold">{testimonial.name}</div>
                      <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-muted/50">
        <div className="container mx-auto px-4">
          <Card className="max-w-4xl mx-auto">
            <CardContent className="p-8 md:p-12 text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Ready to Transform Your SHG?
              </h2>
              <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
                Join thousands of Self Help Groups already using our platform to manage their savings, track loans, and measure their social impact.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/login">
                  <Button size="lg" className="group">
                    Start Your Journey
                    <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
                <Button size="lg" variant="outline">
                  <Shield className="mr-2 h-5 w-5" />
                  View Demo
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Company Info */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Users className="h-6 w-6 text-primary" />
                <span className="text-xl font-semibold">SHG Platform</span>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                Empowering rural communities through digital savings management, transparent governance, and sustainable development.
              </p>
              <div className="flex gap-4">
                <Button variant="ghost" size="sm" className="p-2">
                  <Facebook className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm" className="p-2">
                  <Twitter className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm" className="p-2">
                  <Instagram className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm" className="p-2">
                  <Linkedin className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="font-semibold mb-4">Platform</h3>
              <div className="space-y-2">
                <Link href="/features" className="block text-muted-foreground hover:text-primary transition-colors">Features</Link>
                <Link href="/login" className="block text-muted-foreground hover:text-primary transition-colors">Dashboard</Link>
                <Link href="/about" className="block text-muted-foreground hover:text-primary transition-colors">About Us</Link>
                <Link href="/pricing" className="block text-muted-foreground hover:text-primary transition-colors">Pricing</Link>
              </div>
            </div>

            {/* Support */}
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <div className="space-y-2">
                <a href="#" className="block text-muted-foreground hover:text-primary transition-colors">Help Center</a>
                <a href="#" className="block text-muted-foreground hover:text-primary transition-colors">Documentation</a>
                <a href="#" className="block text-muted-foreground hover:text-primary transition-colors">Training Videos</a>
                <a href="#" className="block text-muted-foreground hover:text-primary transition-colors">Community Forum</a>
              </div>
            </div>

            {/* Contact */}
            <div>
              <h3 className="font-semibold mb-4">Contact</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-muted-foreground">
                  <Phone className="h-4 w-4 flex-shrink-0" />
                  <span>+91 98765 43210</span>
                </div>
                <div className="flex items-center gap-3 text-muted-foreground">
                  <Mail className="h-4 w-4 flex-shrink-0" />
                  <span>support@shgplatform.org</span>
                </div>
                <div className="flex items-center gap-3 text-muted-foreground">
                  <MapPin className="h-4 w-4 flex-shrink-0" />
                  <span>New Delhi, India</span>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-border mt-12 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-muted-foreground text-sm">
                © 2024 SHG Digital Platform. All rights reserved.
              </p>
              <div className="flex gap-6 mt-4 md:mt-0">
                <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">Privacy Policy</a>
                <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">Terms of Service</a>
                <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">Cookie Policy</a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
