import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { AuthGuard } from "@/components/auth/auth-guard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  BarChart3,
  PieChart,
  TrendingUp,
  Download,
  Plus,
  Edit,
  Trash2,
  Eye,
  Filter,
  Calendar,
  Users,
  DollarSign,
  Target,
  Layers
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart as RechartsPieChart, Cell } from "recharts";

interface DashboardWidget {
  id: string;
  type: 'chart' | 'metric' | 'table' | 'list';
  title: string;
  subtitle?: string;
  dataSource: string;
  config: any;
  position: { x: number; y: number; width: number; height: number };
}

interface CustomReport {
  id: string;
  name: string;
  description: string;
  filters: any;
  fields: string[];
  groupBy?: string;
  sortBy?: string;
  createdBy: string;
  createdAt: string;
  isPublic: boolean;
}

const WIDGET_TYPES = [
  { value: "metric", label: "Metric Card", icon: Target },
  { value: "chart", label: "Line Chart", icon: TrendingUp },
  { value: "bar", label: "Bar Chart", icon: BarChart3 },
  { value: "pie", label: "Pie Chart", icon: PieChart },
  { value: "table", label: "Data Table", icon: Layers },
];

const DATA_SOURCES = [
  { value: "savings", label: "Savings Deposits" },
  { value: "loans", label: "Loan Applications" },
  { value: "members", label: "Members" },
  { value: "groups", label: "Groups" },
  { value: "polls", label: "Polls & Votes" },
  { value: "sdg", label: "SDG Impact" },
  { value: "csr", label: "CSR Proposals" },
];

const CHART_COLORS = ['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6', '#06b6d4', '#84cc16'];

export default function AdvancedReports() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [selectedWidget, setSelectedWidget] = useState<DashboardWidget | null>(null);
  const [dashboardWidgets, setDashboardWidgets] = useState<DashboardWidget[]>([]);
  const [customReports, setCustomReports] = useState<CustomReport[]>([]);
  const [isCreatingWidget, setIsCreatingWidget] = useState(false);
  const [isCreatingReport, setIsCreatingReport] = useState(false);

  // Sample data for charts
  const sampleData = {
    savings: [
      { month: 'Jan', amount: 25000, members: 45 },
      { month: 'Feb', amount: 32000, members: 48 },
      { month: 'Mar', amount: 28000, members: 50 },
      { month: 'Apr', amount: 45000, members: 52 },
      { month: 'May', amount: 38000, members: 55 },
      { month: 'Jun', amount: 52000, members: 58 },
    ],
    loans: [
      { status: 'Approved', count: 25, amount: 125000 },
      { status: 'Pending', count: 8, amount: 40000 },
      { status: 'Rejected', count: 3, amount: 15000 },
    ],
    sdg: [
      { goal: 'No Poverty', score: 78 },
      { goal: 'Gender Equality', score: 85 },
      { goal: 'Economic Growth', score: 72 },
      { goal: 'Partnerships', score: 90 },
    ]
  };

  const { data: reportData, isLoading } = useQuery({
    queryKey: ['/api/reports/data'],
    enabled: activeTab === 'reports'
  });

  const DashboardBuilder = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Custom Dashboard</h2>
          <p className="text-muted-foreground">
            Drag and drop widgets to create your personalized dashboard
          </p>
        </div>
        <Button onClick={() => setIsCreatingWidget(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Add Widget
        </Button>
      </div>

      {/* Widget Library */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {WIDGET_TYPES.map((widget) => {
          const Icon = widget.icon;
          return (
            <Card key={widget.value} className="cursor-pointer hover:shadow-md transition-shadow">
              <CardContent className="p-4 text-center">
                <Icon className="h-8 w-8 mx-auto mb-2 text-primary" />
                <h3 className="font-medium">{widget.label}</h3>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Dashboard Canvas */}
      <Card className="min-h-96">
        <CardHeader>
          <CardTitle>Dashboard Canvas</CardTitle>
          <CardDescription>
            Drag widgets here to build your custom dashboard
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Sample Widgets */}
            <Card className="bg-gradient-to-br from-blue-50 to-blue-100">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Savings</p>
                    <p className="text-2xl font-bold text-blue-600">₹2,45,000</p>
                  </div>
                  <DollarSign className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-green-50 to-green-100">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Active Members</p>
                    <p className="text-2xl font-bold text-green-600">58</p>
                  </div>
                  <Users className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-50 to-purple-100">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">SDG Score</p>
                    <p className="text-2xl font-bold text-purple-600">81%</p>
                  </div>
                  <Target className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>

            {/* Sample Chart Widget */}
            <Card className="md:col-span-2 lg:col-span-3">
              <CardHeader>
                <CardTitle>Savings Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={200}>
                  <LineChart data={sampleData.savings}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="amount" stroke="#3b82f6" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const ReportBuilder = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Custom Reports</h2>
          <p className="text-muted-foreground">
            Create and manage custom reports with filters and visualizations
          </p>
        </div>
        <Button onClick={() => setIsCreatingReport(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Create Report
        </Button>
      </div>

      {/* Report Templates */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {[
          {
            title: "Monthly Savings Summary",
            description: "Detailed breakdown of monthly savings by member and group",
            template: "savings-monthly"
          },
          {
            title: "Loan Performance Report",
            description: "Analysis of loan approval rates and repayment patterns",
            template: "loan-performance"
          },
          {
            title: "SDG Impact Assessment",
            description: "Comprehensive SDG goal tracking and impact measurement",
            template: "sdg-impact"
          },
          {
            title: "Member Engagement Report",
            description: "Member participation in meetings, polls, and activities",
            template: "member-engagement"
          },
          {
            title: "Financial Health Dashboard",
            description: "Overall financial health metrics and trends",
            template: "financial-health"
          },
          {
            title: "Group Comparison Report",
            description: "Compare performance across different SHG groups",
            template: "group-comparison"
          }
        ].map((template, index) => (
          <Card key={index} className="cursor-pointer hover:shadow-md transition-shadow">
            <CardHeader>
              <CardTitle className="text-lg">{template.title}</CardTitle>
              <CardDescription>{template.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="outline" className="w-full">
                Use Template
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Existing Reports */}
      <Card>
        <CardHeader>
          <CardTitle>My Reports</CardTitle>
          <CardDescription>Reports you've created and saved</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              {
                name: "Q2 Financial Summary",
                description: "Quarterly financial performance analysis",
                lastRun: "2 days ago",
                isPublic: false
              },
              {
                name: "Member Growth Tracking",
                description: "Monthly member acquisition and retention report",
                lastRun: "1 week ago",
                isPublic: true
              },
              {
                name: "Loan Default Analysis",
                description: "Analysis of loan defaults and risk factors",
                lastRun: "3 days ago",
                isPublic: false
              }
            ].map((report, index) => (
              <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex-1">
                  <h3 className="font-medium">{report.name}</h3>
                  <p className="text-sm text-muted-foreground">{report.description}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant={report.isPublic ? "default" : "secondary"}>
                      {report.isPublic ? "Public" : "Private"}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      Last run: {report.lastRun}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="sm">
                    <Eye className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Download className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const Analytics = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Analytics & Insights</h2>
        <p className="text-muted-foreground">
          Advanced analytics and AI-powered insights for your SHG data
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Savings Trend */}
        <Card>
          <CardHeader>
            <CardTitle>Savings Growth Trend</CardTitle>
            <CardDescription>Monthly savings accumulation pattern</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={sampleData.savings}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="amount" stroke="#3b82f6" strokeWidth={2} />
                <Line type="monotone" dataKey="members" stroke="#10b981" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Loan Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Loan Status Distribution</CardTitle>
            <CardDescription>Current loan application status breakdown</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <RechartsPieChart>
                <Pie
                  data={sampleData.loans}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="count"
                >
                  {sampleData.loans.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </RechartsPieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* SDG Performance */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>SDG Performance Radar</CardTitle>
            <CardDescription>Your group's performance across different SDG goals</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={sampleData.sdg}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="goal" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="score" fill="#8b5cf6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* AI Insights */}
      <Card>
        <CardHeader>
          <CardTitle>AI-Powered Insights</CardTitle>
          <CardDescription>Automated insights and recommendations</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              {
                type: "success",
                title: "Strong Savings Growth",
                description: "Your group's savings have increased by 32% this quarter, exceeding the target by 12%."
              },
              {
                type: "warning",
                title: "Loan Repayment Alert",
                description: "3 members have upcoming loan payments due in the next week. Consider sending reminders."
              },
              {
                type: "info",
                title: "SDG Opportunity",
                description: "Your group can improve 'No Poverty' score by focusing on income-generating activities for 5 identified members."
              },
              {
                type: "tip",
                title: "Engagement Suggestion",
                description: "Member meeting attendance has dropped 15%. Consider scheduling meetings at different times or formats."
              }
            ].map((insight, index) => (
              <div key={index} className="flex items-start gap-3 p-4 rounded-lg bg-muted/50">
                <div className={`w-2 h-2 rounded-full mt-2 ${
                  insight.type === 'success' ? 'bg-green-500' :
                  insight.type === 'warning' ? 'bg-yellow-500' :
                  insight.type === 'info' ? 'bg-blue-500' : 'bg-purple-500'
                }`} />
                <div className="flex-1">
                  <h4 className="font-medium">{insight.title}</h4>
                  <p className="text-sm text-muted-foreground">{insight.description}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <AuthGuard allowedRoles={["ADMIN", "PRESIDENT", "TREASURER"]}>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Advanced Reports & Analytics</h1>
          <p className="text-muted-foreground mt-2">
            Create custom dashboards, generate detailed reports, and gain insights from your SHG data
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="dashboard">Custom Dashboard</TabsTrigger>
            <TabsTrigger value="reports">Report Builder</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard">
            <DashboardBuilder />
          </TabsContent>

          <TabsContent value="reports">
            <ReportBuilder />
          </TabsContent>

          <TabsContent value="analytics">
            <Analytics />
          </TabsContent>
        </Tabs>
      </div>
    </AuthGuard>
  );
}