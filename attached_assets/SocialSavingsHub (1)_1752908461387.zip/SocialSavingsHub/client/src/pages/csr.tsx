import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { AuthGuard } from "@/components/auth/auth-guard";
import { MetricsCard } from "@/components/dashboard/metrics-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ProposalForm } from "@/components/csr/proposal-form";
import { FileText, Plus, CheckCircle, Trophy, Eye } from "lucide-react";
import { CSRProposal } from "@shared/schema";

export default function CSR() {
  const { member } = useAuth();
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const { data: proposals, isLoading } = useQuery({
    queryKey: ["/api/csr", { groupId: member?.groupId }],
    enabled: !!member?.groupId,
  });

  const activeProposals = proposals?.filter((p: CSRProposal) => 
    p.status === "SUBMITTED" || p.status === "UNDER_REVIEW"
  ) || [];
  
  const approvedProposals = proposals?.filter((p: CSRProposal) => 
    p.status === "APPROVED"
  ) || [];

  const totalApprovedAmount = approvedProposals.reduce((sum: number, proposal: CSRProposal) => 
    sum + parseFloat(proposal.requestedAmount), 0
  );

  const getStatusBadge = (status: string) => {
    const variants = {
      DRAFT: "secondary",
      SUBMITTED: "default",
      UNDER_REVIEW: "default",
      APPROVED: "default",
      REJECTED: "destructive",
    } as const;

    const colors = {
      DRAFT: "bg-gray-100 text-gray-800",
      SUBMITTED: "bg-blue-100 text-blue-800",
      UNDER_REVIEW: "bg-yellow-100 text-yellow-800",
      APPROVED: "bg-green-100 text-green-800",
      REJECTED: "bg-red-100 text-red-800",
    } as const;

    return (
      <Badge variant={variants[status as keyof typeof variants] || "secondary"}>
        {status.replace('_', ' ')}
      </Badge>
    );
  };

  if (isLoading) {
    return (
      <AuthGuard>
        <div className="container mx-auto py-8 px-4">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-muted rounded w-1/4"></div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-32 bg-muted rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </AuthGuard>
    );
  }

  return (
    <AuthGuard>
      <div className="container mx-auto py-8 px-4 space-y-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold">CSR Proposals & Fund Allocation</h1>
            <p className="text-muted-foreground">
              Create and manage Corporate Social Responsibility proposals for community development
            </p>
          </div>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Create Proposal
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create New CSR Proposal</DialogTitle>
              </DialogHeader>
              <ProposalForm onSuccess={() => setIsDialogOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>

        {/* Hero Card */}
        <Card className="bg-gradient-to-br from-green-50 to-blue-50 border-green-200">
          <CardContent className="p-8 text-center">
            <FileText className="h-16 w-16 text-green-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Corporate Social Responsibility</h2>
            <p className="text-muted-foreground">
              Partner with corporations to create lasting impact in rural communities through strategic funding proposals.
            </p>
          </CardContent>
        </Card>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <MetricsCard
            title="Active Proposals"
            value={activeProposals.length}
            subtitle="Under review"
            icon={FileText}
          />
          
          <MetricsCard
            title="Approved Funding"
            value={`₹${(totalApprovedAmount / 100000).toFixed(1)}L`}
            subtitle="This fiscal year"
            icon={CheckCircle}
          />
          
          <MetricsCard
            title="Projects Completed"
            value={approvedProposals.length}
            subtitle="Successfully delivered"
            icon={Trophy}
          />
        </div>

        {/* Proposals Table */}
        <Card>
          <CardHeader>
            <CardTitle>All Proposals</CardTitle>
          </CardHeader>
          <CardContent>
            {!proposals || proposals.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">No Proposals Yet</h3>
                <p className="text-muted-foreground mb-6">
                  Create your first CSR proposal to start partnering with corporations for community development.
                </p>
                <Button onClick={() => setIsDialogOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Create First Proposal
                </Button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Proposal ID</TableHead>
                      <TableHead>Project Title</TableHead>
                      <TableHead>Requested Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Created Date</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {proposals.map((proposal: CSRProposal) => (
                      <TableRow key={proposal.id}>
                        <TableCell className="font-medium">
                          CSR-{proposal.id.toString().padStart(4, '0')}
                        </TableCell>
                        <TableCell>{proposal.title}</TableCell>
                        <TableCell>
                          ₹{parseFloat(proposal.requestedAmount).toLocaleString()}
                        </TableCell>
                        <TableCell>{getStatusBadge(proposal.status)}</TableCell>
                        <TableCell>
                          {new Date(proposal.createdAt).toLocaleDateString()}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              <Eye className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AuthGuard>
  );
}
