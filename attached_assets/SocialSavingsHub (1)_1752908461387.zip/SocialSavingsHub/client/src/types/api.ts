import type { User, Member, Group, SavingDeposit, LoanApplication, Poll, SDGImpact, CSRProposal } from "@shared/schema";

export interface AuthResponse {
  token: string;
  user: {
    id: number;
    username: string;
    email: string;
    role: string;
  };
  member: Member | null;
}

export interface DashboardStats {
  totalSavings: number;
  totalLoanAmount: number;
  memberCount: number;
  pendingApprovals: number;
  sdgScore: number;
  sdgGoalsImpacted: number;
  groupBalance: number;
}

export interface LoanWithMember extends LoanApplication {
  memberName?: string;
  memberPhone?: string;
}

export interface SavingDepositWithMember extends SavingDeposit {
  memberName?: string;
}

export interface PollWithVotes extends Poll {
  votes?: {
    [option: string]: number;
  };
  totalVotes?: number;
  hasVoted?: boolean;
  userVote?: string;
}

export interface CSRProposalWithDetails extends CSRProposal {
  groupName?: string;
  sdgGoalTitles?: string[];
}
