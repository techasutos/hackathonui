import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import {
  Home,
  BarChart3,
  CreditCard,
  PiggyBank,
  Globe,
  Users,
  Building,
  Vote,
  HandHeart,
  User,
  Settings,
  LogOut,
  Info,
  Star,
} from "lucide-react";

interface MobileSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export function MobileSidebar({ isOpen, onClose }: MobileSidebarProps) {
  const [location] = useLocation();
  const { isAuthenticated, user, logout } = useAuth();

  const handleLogout = () => {
    logout();
    onClose();
    window.location.href = "/";
  };

  const menuItems = isAuthenticated
    ? [
        { href: "/dashboard", label: "Dashboard", icon: BarChart3 },
        { href: "/loans", label: "Loans", icon: CreditCard },
        { href: "/savings", label: "Savings", icon: PiggyBank },
        { href: "/sdg-tracking", label: "SDG Tracking", icon: Globe },
        { href: "/members", label: "Members", icon: Users },
        { href: "/groups", label: "Groups", icon: Building },
        { href: "/polls", label: "Polls", icon: Vote },
        { href: "/csr", label: "CSR", icon: HandHeart },
      ]
    : [
        { href: "/", label: "Home", icon: Home },
        { href: "/about", label: "About", icon: Info },
        { href: "/features", label: "Features", icon: Star },
      ];

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="left" className="w-80 p-0">
        <SheetHeader className="p-6 border-b">
          <SheetTitle className="text-left">SHG Platform</SheetTitle>
        </SheetHeader>
        
        <div className="flex flex-col h-full">
          <div className="flex-1 py-4">
            <nav className="space-y-1 px-4">
              {menuItems.map((item) => {
                const Icon = item.icon;
                const isActive = location === item.href;
                
                return (
                  <Link key={item.href} href={item.href}>
                    <Button
                      variant={isActive ? "secondary" : "ghost"}
                      className="w-full justify-start gap-3"
                      onClick={onClose}
                    >
                      <Icon className="h-4 w-4" />
                      {item.label}
                    </Button>
                  </Link>
                );
              })}
            </nav>
          </div>

          {isAuthenticated && (
            <div className="border-t p-4 space-y-1">
              <Link href="/profile">
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-3"
                  onClick={onClose}
                >
                  <User className="h-4 w-4" />
                  Profile
                </Button>
              </Link>
              
              <Link href="/settings">
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-3"
                  onClick={onClose}
                >
                  <Settings className="h-4 w-4" />
                  Settings
                </Button>
              </Link>
              
              <Button
                variant="ghost"
                className="w-full justify-start gap-3 text-destructive hover:text-destructive"
                onClick={handleLogout}
              >
                <LogOut className="h-4 w-4" />
                Logout
              </Button>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}
