import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { SavingDeposit } from "@shared/schema";

interface SavingsTableProps {
  deposits: SavingDeposit[];
  showMemberName?: boolean;
  onDownloadReceipt?: (depositId: number) => void;
}

export function SavingsTable({
  deposits,
  showMemberName = false,
  onDownloadReceipt,
}: SavingsTableProps) {
  if (deposits.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">No savings deposits found</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Date</TableHead>
            {showMemberName && <TableHead>Member</TableHead>}
            <TableHead>Amount</TableHead>
            <TableHead>Remarks</TableHead>
            <TableHead>Receipt</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {deposits.map((deposit: SavingDeposit) => (
            <TableRow key={deposit.id}>
              <TableCell>
                {new Date(deposit.depositDate).toLocaleDateString()}
              </TableCell>
              {showMemberName && (
                <TableCell>Member {deposit.memberId}</TableCell>
              )}
              <TableCell className="font-medium">
                ₹{parseFloat(deposit.amount).toLocaleString()}
              </TableCell>
              <TableCell>
                {deposit.remarks || "Regular savings"}
              </TableCell>
              <TableCell>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onDownloadReceipt?.(deposit.id)}
                >
                  <Download className="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
