import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { SDGImpact } from "@shared/schema";

interface SDGGoalCardProps {
  goal: {
    number: number;
    title: string;
    color: string;
    description: string;
  };
  impact?: SDGImpact;
}

export function SDGGoalCard({ goal, impact }: SDGGoalCardProps) {
  const impactScore = impact?.impactScore || 0;
  const isActive = !!impact;

  return (
    <Card className={`transition-all duration-200 hover:shadow-md ${
      isActive ? 'border-l-4 bg-gradient-to-r from-white to-gray-50' : 'opacity-60'
    }`} style={{ borderLeftColor: isActive ? goal.color : undefined }}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div
            className="w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold text-sm"
            style={{ backgroundColor: goal.color }}
          >
            {goal.number}
          </div>
          {isActive && (
            <Badge variant="secondary" className="text-xs">
              {impactScore}%
            </Badge>
          )}
        </div>
        
        <h3 className="font-semibold text-sm mb-2 line-clamp-2">
          {goal.title}
        </h3>
        
        <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
          {goal.description}
        </p>
        
        {isActive && (
          <div className="space-y-2">
            <Progress value={impactScore} className="h-2" />
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-muted-foreground">Jobs:</span>
                <span className="font-medium ml-1">{impact?.jobsCreated || 0}</span>
              </div>
              <div>
                <span className="text-muted-foreground">Women:</span>
                <span className="font-medium ml-1">{impact?.womenEmpowered || 0}</span>
              </div>
            </div>
          </div>
        )}
        
        {!isActive && (
          <div className="text-xs text-muted-foreground">
            No current impact recorded
          </div>
        )}
      </CardContent>
    </Card>
  );
}
