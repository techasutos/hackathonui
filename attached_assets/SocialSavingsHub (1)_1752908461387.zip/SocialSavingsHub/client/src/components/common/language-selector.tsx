import { useState } from "react";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Globe, ChevronDown } from "lucide-react";
import { useLanguage, SUPPORTED_LANGUAGES } from "@/contexts/language-context";

interface LanguageSelectorProps {
  variant?: 'compact' | 'full';
}

export function LanguageSelector({ variant = 'full' }: LanguageSelectorProps) {
  const { currentLanguage, setLanguage } = useLanguage();

  if (variant === 'compact') {
    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="sm" className="h-9 px-2">
            <Globe className="h-4 w-4" />
            <span className="ml-1 hidden sm:inline">{currentLanguage.code.toUpperCase()}</span>
            <ChevronDown className="h-3 w-3 ml-1" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="min-w-[200px]">
          {SUPPORTED_LANGUAGES.map((language) => (
            <DropdownMenuItem
              key={language.code}
              onClick={() => setLanguage(language.code)}
              className={`flex items-center justify-between ${
                currentLanguage.code === language.code ? 'bg-accent' : ''
              }`}
            >
              <span>{language.nativeName}</span>
              <span className="text-xs text-muted-foreground">{language.name}</span>
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    );
  }

  return (
    <div className="space-y-2">
      <label className="text-sm font-medium">Language / भाषा</label>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="w-full justify-between">
            <div className="flex items-center gap-2">
              <Globe className="h-4 w-4" />
              <span>{currentLanguage.nativeName}</span>
            </div>
            <ChevronDown className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-full min-w-[250px]">
          {SUPPORTED_LANGUAGES.map((language) => (
            <DropdownMenuItem
              key={language.code}
              onClick={() => setLanguage(language.code)}
              className={`flex items-center justify-between p-3 ${
                currentLanguage.code === language.code ? 'bg-accent' : ''
              }`}
            >
              <div className="flex flex-col">
                <span className="font-medium">{language.nativeName}</span>
                <span className="text-xs text-muted-foreground">{language.name}</span>
              </div>
              {currentLanguage.code === language.code && (
                <div className="w-2 h-2 bg-primary rounded-full" />
              )}
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}