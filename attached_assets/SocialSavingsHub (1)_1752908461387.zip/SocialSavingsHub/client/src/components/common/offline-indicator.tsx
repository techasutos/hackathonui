import { useOffline } from "@/hooks/use-offline";
import { Badge } from "@/components/ui/badge";
import { Wifi, WifiOff, Clock, CheckCircle } from "lucide-react";

export function OfflineIndicator() {
  const { isOnline, pendingSync } = useOffline();

  const pendingCount = 
    pendingSync.savingsDeposits.length + 
    pendingSync.loanApplications.length + 
    pendingSync.pollVotes.length;

  if (isOnline && pendingCount === 0) {
    return (
      <Badge variant="outline" className="bg-green-50 border-green-200 text-green-700">
        <CheckCircle className="mr-1 h-3 w-3" />
        Online
      </Badge>
    );
  }

  if (isOnline && pendingCount > 0) {
    return (
      <Badge variant="outline" className="bg-blue-50 border-blue-200 text-blue-700">
        <Clock className="mr-1 h-3 w-3 animate-spin" />
        Syncing {pendingCount} items
      </Badge>
    );
  }

  return (
    <Badge variant="outline" className="bg-red-50 border-red-200 text-red-700">
      <WifiOff className="mr-1 h-3 w-3" />
      Offline {pendingCount > 0 && `(${pendingCount} pending)`}
    </Badge>
  );
}