import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertCSRProposalSchema } from "@shared/schema";
import { z } from "zod";

const formSchema = insertCSRProposalSchema.extend({
  requestedAmount: z.string().min(1, "Amount is required"),
  sdgGoals: z.array(z.number()).min(1, "At least one SDG goal must be selected"),
});

interface ProposalFormProps {
  onSuccess?: () => void;
}

export function ProposalForm({ onSuccess }: ProposalFormProps) {
  const { member } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      groupId: member?.groupId || 0,
      title: "",
      description: "",
      requestedAmount: "",
      sdgGoals: [],
    },
  });

  const createProposalMutation = useMutation({
    mutationFn: async (data: z.infer<typeof formSchema>) => {
      const response = await apiRequest("POST", "/api/csr", {
        ...data,
        requestedAmount: parseFloat(data.requestedAmount),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/csr"] });
      toast({
        title: "Success",
        description: "CSR proposal created successfully",
      });
      form.reset();
      onSuccess?.();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create CSR proposal",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: z.infer<typeof formSchema>) => {
    createProposalMutation.mutate(data);
  };

  const sdgGoals = [
    { number: 1, title: "No Poverty" },
    { number: 2, title: "Zero Hunger" },
    { number: 3, title: "Good Health and Well-being" },
    { number: 4, title: "Quality Education" },
    { number: 5, title: "Gender Equality" },
    { number: 6, title: "Clean Water and Sanitation" },
    { number: 7, title: "Affordable and Clean Energy" },
    { number: 8, title: "Decent Work and Economic Growth" },
    { number: 9, title: "Industry, Innovation and Infrastructure" },
    { number: 10, title: "Reduced Inequalities" },
    { number: 11, title: "Sustainable Cities and Communities" },
    { number: 12, title: "Responsible Consumption and Production" },
    { number: 13, title: "Climate Action" },
    { number: 14, title: "Life Below Water" },
    { number: 15, title: "Life on Land" },
    { number: 16, title: "Peace, Justice and Strong Institutions" },
    { number: 17, title: "Partnerships for the Goals" },
  ];

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Project Title</FormLabel>
              <FormControl>
                <Input
                  {...field}
                  placeholder="Enter a compelling project title"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="requestedAmount"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Requested Amount (₹)</FormLabel>
              <FormControl>
                <Input
                  {...field}
                  type="number"
                  placeholder="Enter funding amount"
                  min="10000"
                  step="1000"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="sdgGoals"
          render={() => (
            <FormItem>
              <FormLabel>SDG Goals Aligned</FormLabel>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-60 overflow-y-auto border rounded-md p-4">
                {sdgGoals.map((goal) => (
                  <FormField
                    key={goal.number}
                    control={form.control}
                    name="sdgGoals"
                    render={({ field }) => {
                      return (
                        <FormItem
                          key={goal.number}
                          className="flex flex-row items-start space-x-3 space-y-0"
                        >
                          <FormControl>
                            <Checkbox
                              checked={field.value?.includes(goal.number)}
                              onCheckedChange={(checked) => {
                                return checked
                                  ? field.onChange([...field.value, goal.number])
                                  : field.onChange(
                                      field.value?.filter(
                                        (value) => value !== goal.number
                                      )
                                    );
                              }}
                            />
                          </FormControl>
                          <div className="grid gap-1.5 leading-none">
                            <FormLabel className="text-sm font-normal cursor-pointer">
                              SDG {goal.number}: {goal.title}
                            </FormLabel>
                          </div>
                        </FormItem>
                      );
                    }}
                  />
                ))}
              </div>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Project Description</FormLabel>
              <FormControl>
                <Textarea
                  {...field}
                  placeholder="Provide a detailed description of your project, including objectives, methodology, expected outcomes, and community impact..."
                  rows={8}
                  className="resize-none"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="bg-muted/50 p-4 rounded-lg">
          <h4 className="font-medium mb-2">Proposal Summary</h4>
          <div className="text-sm space-y-1">
            <div className="flex justify-between">
              <span>Project:</span>
              <span className="font-medium">
                {form.watch("title") || "Not specified"}
              </span>
            </div>
            <div className="flex justify-between">
              <span>Amount:</span>
              <span className="font-medium">
                ₹{form.watch("requestedAmount") ? parseFloat(form.watch("requestedAmount")).toLocaleString() : "0"}
              </span>
            </div>
            <div className="flex justify-between">
              <span>SDG Goals:</span>
              <span className="font-medium">
                {form.watch("sdgGoals").length} selected
              </span>
            </div>
          </div>
        </div>

        <Button
          type="submit"
          className="w-full"
          disabled={createProposalMutation.isPending}
        >
          {createProposalMutation.isPending ? "Creating..." : "Create Proposal"}
        </Button>
      </form>
    </Form>
  );
}
