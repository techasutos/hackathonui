import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Eye, CheckCircle, XCircle } from "lucide-react";
import { LoanApplication } from "@shared/schema";

interface LoanTableProps {
  loans: LoanApplication[];
  onView?: (loan: LoanApplication) => void;
  onApprove?: (loanId: number) => void;
  onReject?: (loanId: number) => void;
  onDisburse?: (loanId: number) => void;
  canApprove?: boolean;
  canDisburse?: boolean;
  isLoading?: boolean;
}

export function LoanTable({
  loans,
  onView,
  onApprove,
  onReject,
  onDisburse,
  canApprove = false,
  canDisburse = false,
  isLoading = false,
}: LoanTableProps) {
  const getStatusBadge = (status: string) => {
    const variants = {
      PENDING: "secondary",
      APPROVED: "default",
      DISBURSED: "default",
      REPAID: "default",
      REJECTED: "destructive",
    } as const;

    return (
      <Badge variant={variants[status as keyof typeof variants] || "secondary"}>
        {status}
      </Badge>
    );
  };

  if (loans.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">No loan applications found</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Application ID</TableHead>
            <TableHead>Member</TableHead>
            <TableHead>Amount</TableHead>
            <TableHead>Purpose</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Applied Date</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {loans.map((loan: LoanApplication) => (
            <TableRow key={loan.id}>
              <TableCell className="font-medium">
                LA-{loan.id.toString().padStart(4, '0')}
              </TableCell>
              <TableCell>Member {loan.memberId}</TableCell>
              <TableCell>₹{parseFloat(loan.amount).toLocaleString()}</TableCell>
              <TableCell className="capitalize">{loan.purpose}</TableCell>
              <TableCell>{getStatusBadge(loan.status)}</TableCell>
              <TableCell>
                {new Date(loan.appliedAt).toLocaleDateString()}
              </TableCell>
              <TableCell>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onView?.(loan)}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                  
                  {loan.status === "PENDING" && canApprove && (
                    <>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onApprove?.(loan.id)}
                        disabled={isLoading}
                      >
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      </Button>
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onReject?.(loan.id)}
                        disabled={isLoading}
                      >
                        <XCircle className="h-4 w-4 text-red-600" />
                      </Button>
                    </>
                  )}
                  
                  {loan.status === "APPROVED" && canDisburse && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onDisburse?.(loan.id)}
                      disabled={isLoading}
                    >
                      Disburse
                    </Button>
                  )}
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
