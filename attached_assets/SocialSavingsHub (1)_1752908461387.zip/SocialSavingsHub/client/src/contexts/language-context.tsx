import { createContext, useContext, useState, useEffect, ReactNode } from "react";

export interface Language {
  code: string;
  name: string;
  nativeName: string;
  rtl?: boolean;
}

export const SUPPORTED_LANGUAGES: Language[] = [
  { code: "en", name: "English", nativeName: "English" },
  { code: "hi", name: "Hindi", nativeName: "हिंदी" },
  { code: "bn", name: "Bengali", nativeName: "বাংলা" },
  { code: "ta", name: "Tamil", nativeName: "தமிழ்" },
  { code: "te", name: "Telugu", nativeName: "తెలుగు" },
  { code: "mr", name: "Marathi", nativeName: "मराठी" },
  { code: "gu", name: "Gujarati", nativeName: "ગુજરાતી" },
  { code: "kn", name: "Kannada", nativeName: "ಕನ್ನಡ" },
  { code: "ml", name: "Malayalam", nativeName: "മലയാളം" },
  { code: "pa", name: "Punjabi", nativeName: "ਪੰਜਾਬੀ" },
  { code: "or", name: "Odia", nativeName: "ଓଡ଼ିଆ" },
  { code: "as", name: "Assamese", nativeName: "অসমীয়া" },
];

interface LanguageContextType {
  currentLanguage: Language;
  setLanguage: (languageCode: string) => void;
  t: (key: string, params?: Record<string, string>) => string;
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Translation keys and values
const translations: Record<string, Record<string, string>> = {
  en: {
    // Navigation
    "nav.home": "Home",
    "nav.dashboard": "Dashboard",
    "nav.savings": "Savings",
    "nav.loans": "Loans",
    "nav.polls": "Polls",
    "nav.members": "Members",
    "nav.groups": "Groups",
    "nav.sdg": "SDG Tracking",
    "nav.csr": "CSR Proposals",
    "nav.profile": "Profile",
    "nav.settings": "Settings",
    "nav.logout": "Logout",
    "nav.login": "Login",
    "nav.getStarted": "Get Started",
    
    // Landing Page
    "landing.hero.title": "Empowering Rural Communities Through Digital Savings",
    "landing.hero.subtitle": "A comprehensive platform for Self Help Groups to manage savings, loans, and community development initiatives aligned with SDG goals.",
    "landing.hero.cta": "Start Your Journey",
    "landing.hero.learnMore": "Learn More",
    
    // Features
    "features.savings.title": "Digital Savings Management",
    "features.savings.description": "Track individual and group savings with automated calculations, monthly summaries, and export capabilities for transparent financial management.",
    "features.loans.title": "Smart Loan Processing",
    "features.loans.description": "Streamlined loan application, approval workflow with role-based permissions, and automated repayment tracking for efficient fund utilization.",
    "features.governance.title": "Governance & Polling",
    "features.governance.description": "Digital voting system for group decisions, meeting attendance tracking, and transparent governance with audit trails for accountability.",
    "features.sdg.title": "SDG Impact Tracking",
    "features.sdg.description": "Automatic mapping of activities to Sustainable Development Goals with impact analytics, progress monitoring, and compliance reporting.",
    
    // Dashboard
    "dashboard.welcome": "Welcome back",
    "dashboard.totalSavings": "Total Savings",
    "dashboard.activeLoans": "Active Loans",
    "dashboard.members": "Members",
    "dashboard.sdgScore": "SDG Score",
    
    // Forms
    "form.submit": "Submit",
    "form.cancel": "Cancel",
    "form.save": "Save",
    "form.loading": "Loading...",
    "form.required": "This field is required",
    
    // Messages
    "message.success": "Operation completed successfully",
    "message.error": "An error occurred",
    "message.confirm": "Are you sure?",
    
    // Common
    "common.yes": "Yes",
    "common.no": "No",
    "common.close": "Close",
    "common.open": "Open",
    "common.edit": "Edit",
    "common.delete": "Delete",
    "common.view": "View",
    "common.add": "Add",
    "common.search": "Search",
    "common.filter": "Filter",
    "common.sort": "Sort",
    "common.export": "Export",
    "common.import": "Import",
    "common.date": "Date",
    "common.amount": "Amount",
    "common.status": "Status",
    "common.description": "Description",
    "common.name": "Name",
    "common.email": "Email",
    "common.phone": "Phone",
    "common.address": "Address",
  },
  hi: {
    // Navigation
    "nav.home": "मुख्य पृष्ठ",
    "nav.dashboard": "डैशबोर्ड",
    "nav.savings": "बचत",
    "nav.loans": "ऋण",
    "nav.polls": "मतदान",
    "nav.members": "सदस्य",
    "nav.groups": "समूह",
    "nav.sdg": "एसडीजी ट्रैकिंग",
    "nav.csr": "सीएसआर प्रस्ताव",
    "nav.profile": "प्रोफ़ाइल",
    "nav.settings": "सेटिंग्स",
    "nav.logout": "लॉग आउट",
    "nav.login": "लॉग इन",
    "nav.getStarted": "शुरू करें",
    
    // Landing Page
    "landing.hero.title": "डिजिटल बचत के माध्यम से ग्रामीण समुदायों को सशक्त बनाना",
    "landing.hero.subtitle": "स्वयं सहायता समूहों के लिए बचत, ऋण और एसडीजी लक्ष्यों के साथ सामुदायिक विकास पहलों का प्रबंधन करने के लिए एक व्यापक मंच।",
    "landing.hero.cta": "अपनी यात्रा शुरू करें",
    "landing.hero.learnMore": "और जानें",
    
    // Features
    "features.savings.title": "डिजिटल बचत प्रबंधन",
    "features.savings.description": "पारदर्शी वित्तीय प्रबंधन के लिए स्वचालित गणना, मासिक सारांश और निर्यात क्षमताओं के साथ व्यक्तिगत और समूह बचत को ट्रैक करें।",
    "features.loans.title": "स्मार्ट ऋण प्रसंस्करण",
    "features.loans.description": "भूमिका-आधारित अनुमतियों के साथ सुव्यवस्थित ऋण आवेदन, अनुमोदन वर्कफ़्लो, और कुशल फंड उपयोग के लिए स्वचालित पुनर्भुगतान ट्रैकिंग।",
    "features.governance.title": "शासन और मतदान",
    "features.governance.description": "समूह निर्णयों के लिए डिजिटल वोटिंग सिस्टम, बैठक उपस्थिति ट्रैकिंग, और जवाबदेही के लिए ऑडिट ट्रेल्स के साथ पारदर्शी शासन।",
    "features.sdg.title": "एसडीजी प्रभाव ट्रैकिंग",
    "features.sdg.description": "प्रभाव विश्लेषण, प्रगति निगरानी और अनुपालन रिपोर्टिंग के साथ सतत विकास लक्ष्यों के लिए गतिविधियों की स्वचालित मैपिंग।",
    
    // Dashboard
    "dashboard.welcome": "वापसी पर स्वागत है",
    "dashboard.totalSavings": "कुल बचत",
    "dashboard.activeLoans": "सक्रिय ऋण",
    "dashboard.members": "सदस्य",
    "dashboard.sdgScore": "एसडीजी स्कोर",
    
    // Forms
    "form.submit": "जमा करें",
    "form.cancel": "रद्द करें",
    "form.save": "सेव करें",
    "form.loading": "लोड हो रहा है...",
    "form.required": "यह फील्ड आवश्यक है",
    
    // Messages
    "message.success": "ऑपरेशन सफलतापूर्वक पूरा हुआ",
    "message.error": "एक त्रुटि हुई",
    "message.confirm": "क्या आप वाकई चाहते हैं?",
    
    // Common
    "common.yes": "हाँ",
    "common.no": "नहीं",
    "common.close": "बंद करें",
    "common.open": "खोलें",
    "common.edit": "संपादित करें",
    "common.delete": "हटाएं",
    "common.view": "देखें",
    "common.add": "जोड़ें",
    "common.search": "खोजें",
    "common.filter": "फिल्टर",
    "common.sort": "क्रमबद्ध करें",
    "common.export": "निर्यात",
    "common.import": "आयात",
    "common.date": "दिनांक",
    "common.amount": "राशि",
    "common.status": "स्थिति",
    "common.description": "विवरण",
    "common.name": "नाम",
    "common.email": "ईमेल",
    "common.phone": "फोन",
    "common.address": "पता",
  },
};

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [currentLanguage, setCurrentLanguage] = useState<Language>(SUPPORTED_LANGUAGES[0]);

  useEffect(() => {
    // Load saved language from localStorage
    const savedLanguageCode = localStorage.getItem("shg_language");
    if (savedLanguageCode) {
      const savedLanguage = SUPPORTED_LANGUAGES.find(lang => lang.code === savedLanguageCode);
      if (savedLanguage) {
        setCurrentLanguage(savedLanguage);
      }
    } else {
      // Detect browser language
      const browserLang = navigator.language.split('-')[0];
      const detectedLanguage = SUPPORTED_LANGUAGES.find(lang => lang.code === browserLang);
      if (detectedLanguage) {
        setCurrentLanguage(detectedLanguage);
      }
    }
  }, []);

  useEffect(() => {
    // Set document direction for RTL languages
    document.documentElement.dir = currentLanguage.rtl ? "rtl" : "ltr";
    document.documentElement.lang = currentLanguage.code;
  }, [currentLanguage]);

  const setLanguage = (languageCode: string) => {
    const language = SUPPORTED_LANGUAGES.find(lang => lang.code === languageCode);
    if (language) {
      setCurrentLanguage(language);
      localStorage.setItem("shg_language", languageCode);
    }
  };

  const t = (key: string, params?: Record<string, string>): string => {
    let translation = translations[currentLanguage.code]?.[key] || translations.en[key] || key;
    
    // Replace parameters in translation
    if (params) {
      Object.entries(params).forEach(([paramKey, paramValue]) => {
        translation = translation.replace(`{{${paramKey}}}`, paramValue);
      });
    }
    
    return translation;
  };

  const value: LanguageContextType = {
    currentLanguage,
    setLanguage,
    t,
    isRTL: currentLanguage.rtl || false,
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    // Provide fallback during development/testing
    return {
      currentLanguage: { code: "en", name: "English", nativeName: "English" },
      setLanguage: () => {},
      t: (key: string) => key.split('.').pop() || key,
      isRTL: false
    };
  }
  return context;
}