import { AuthResponse } from "@/types/api";

const TOKEN_KEY = "shg_auth_token";
const USER_KEY = "shg_user_data";

export function getAuthToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setAuthToken(token: string): void {
  localStorage.setItem(TOKEN_KEY, token);
}

export function removeAuthToken(): void {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
}

export function getStoredUser(): AuthResponse["user"] | null {
  const userData = localStorage.getItem(USER_KEY);
  return userData ? JSON.parse(userData) : null;
}

export function setStoredUser(user: AuthResponse["user"]): void {
  localStorage.setItem(USER_KEY, JSON.stringify(user));
}

export function getStoredMember(): AuthResponse["member"] | null {
  const memberData = localStorage.getItem("shg_member_data");
  return memberData ? JSON.parse(memberData) : null;
}

export function setStoredMember(member: AuthResponse["member"]): void {
  if (member) {
    localStorage.setItem("shg_member_data", JSON.stringify(member));
  } else {
    localStorage.removeItem("shg_member_data");
  }
}

export function isAuthenticated(): boolean {
  return !!getAuthToken();
}

export function hasRole(requiredRoles: string[]): boolean {
  const user = getStoredUser();
  return user ? requiredRoles.includes(user.role) : false;
}

export function isAdmin(): boolean {
  return hasRole(["ADMIN"]);
}

export function isPresident(): boolean {
  return hasRole(["ADMIN", "PRESIDENT"]);
}

export function isTreasurer(): boolean {
  return hasRole(["ADMIN", "PRESIDENT", "TREASURER"]);
}
