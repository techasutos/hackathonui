import { Switch, Route } from "wouter";
import { useState } from "react";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { AuthProvider } from "./hooks/use-auth";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Navbar } from "@/components/layout/navbar";
import { MobileSidebar } from "@/components/layout/mobile-sidebar";
import { InstallPrompt } from "@/components/common/install-prompt";

// Pages
import Landing from "@/pages/landing";
import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import Loans from "@/pages/loans";
import Savings from "@/pages/savings";
import SDGTracking from "@/pages/sdg-tracking";
import Members from "@/pages/members";
import Groups from "@/pages/groups";
import Polls from "@/pages/polls";
import CSR from "@/pages/csr";
import Profile from "@/pages/profile";
import Settings from "@/pages/settings";
import AdvancedReports from "@/pages/advanced-reports";
import NotFound from "@/pages/not-found";

function Router() {
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <Navbar onMobileMenuToggle={() => setIsMobileSidebarOpen(true)} />
      <MobileSidebar
        isOpen={isMobileSidebarOpen}
        onClose={() => setIsMobileSidebarOpen(false)}
      />
      
      <main className="main-content">
        <Switch>
          <Route path="/" component={Landing} />
          <Route path="/login" component={Login} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/loans" component={Loans} />
          <Route path="/savings" component={Savings} />
          <Route path="/sdg-tracking" component={SDGTracking} />
          <Route path="/members" component={Members} />
          <Route path="/groups" component={Groups} />
          <Route path="/polls" component={Polls} />
          <Route path="/csr" component={CSR} />
          <Route path="/profile" component={Profile} />
          <Route path="/settings" component={Settings} />
          <Route path="/reports" component={AdvancedReports} />
          <Route component={NotFound} />
        </Switch>
      </main>
      
      <InstallPrompt />
    </div>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Router />
          <Toaster />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}
