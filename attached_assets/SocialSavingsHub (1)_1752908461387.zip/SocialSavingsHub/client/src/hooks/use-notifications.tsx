import { useState, useEffect } from "react";
import { useAuth } from "./use-auth";

export interface NotificationPreferences {
  smsEnabled: boolean;
  whatsappEnabled: boolean;
  emailEnabled: boolean;
  pushEnabled: boolean;
  loanUpdates: boolean;
  savingsReminders: boolean;
  meetingAlerts: boolean;
  pollNotifications: boolean;
  phoneNumber?: string;
  whatsappNumber?: string;
}

export interface NotificationTemplate {
  id: string;
  type: 'sms' | 'whatsapp' | 'email' | 'push';
  event: 'loan_approved' | 'loan_rejected' | 'meeting_reminder' | 'savings_reminder' | 'poll_created' | 'payment_due';
  template: string;
  language: string;
}

const defaultPreferences: NotificationPreferences = {
  smsEnabled: true,
  whatsappEnabled: false,
  emailEnabled: true,
  pushEnabled: true,
  loanUpdates: true,
  savingsReminders: true,
  meetingAlerts: true,
  pollNotifications: true,
};

const notificationTemplates: Record<string, Record<string, string>> = {
  en: {
    loan_approved: "🎉 Great news! Your loan of ₹{{amount}} has been approved. You can collect it from your group treasurer. - SHG Platform",
    loan_rejected: "Your loan application for ₹{{amount}} needs review. Please contact your group president for details. - SHG Platform",
    meeting_reminder: "📅 Reminder: Group meeting tomorrow at {{time}}. Don't forget to bring your savings! - SHG Platform",
    savings_reminder: "💰 Monthly savings due: ₹{{amount}}. Submit by {{date}} to avoid late fees. - SHG Platform",
    poll_created: "🗳️ New poll: {{title}}. Cast your vote before {{deadline}}. Your voice matters! - SHG Platform",
    payment_due: "⏰ Loan payment of ₹{{amount}} due on {{date}}. Please arrange payment to avoid penalties. - SHG Platform"
  },
  hi: {
    loan_approved: "🎉 बधाई हो! आपका ₹{{amount}} का ऋण स्वीकृत हो गया है। आप इसे अपने समूह कोषाध्यक्ष से ले सकते हैं। - SHG प्लेटफॉर्म",
    loan_rejected: "आपके ₹{{amount}} के ऋण आवेदन की समीक्षा आवश्यक है। विवरण के लिए अपने समूह अध्यक्ष से संपर्क करें। - SHG प्लेटफॉर्म",
    meeting_reminder: "📅 स्मरण: कल {{time}} बजे समूह की बैठक। अपनी बचत लाना न भूलें! - SHG प्लेटफॉर्म",
    savings_reminder: "💰 मासिक बचत देय: ₹{{amount}}। विलंब शुल्क से बचने के लिए {{date}} तक जमा करें। - SHG प्लेटफॉर्म",
    poll_created: "🗳️ नया मतदान: {{title}}। {{deadline}} से पहले अपना वोट दें। आपकी आवाज़ मायने रखती है! - SHG प्लेटफॉर्म",
    payment_due: "⏰ ₹{{amount}} का ऋण भुगतान {{date}} को देय है। दंड से बचने के लिए भुगतान की व्यवस्था करें। - SHG प्लेटफॉर्म"
  }
};

export function useNotifications() {
  const [preferences, setPreferences] = useState<NotificationPreferences>(defaultPreferences);
  const [pushSupported, setPushSupported] = useState(false);
  const [pushPermission, setPushPermission] = useState<NotificationPermission>('default');
  const { user } = useAuth();

  useEffect(() => {
    // Check push notification support
    if ('Notification' in window && 'serviceWorker' in navigator && 'PushManager' in window) {
      setPushSupported(true);
      setPushPermission(Notification.permission);
    }

    // Load saved preferences
    loadPreferences();
  }, [user]);

  const loadPreferences = async () => {
    try {
      const saved = localStorage.getItem('notification_preferences');
      if (saved) {
        setPreferences({ ...defaultPreferences, ...JSON.parse(saved) });
      }
    } catch (error) {
      console.error('Failed to load notification preferences:', error);
    }
  };

  const savePreferences = async (newPreferences: NotificationPreferences) => {
    try {
      setPreferences(newPreferences);
      localStorage.setItem('notification_preferences', JSON.stringify(newPreferences));
      
      // Send preferences to server
      await fetch('/api/users/notification-preferences', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('shg_auth_token')}`
        },
        body: JSON.stringify(newPreferences)
      });
    } catch (error) {
      console.error('Failed to save notification preferences:', error);
    }
  };

  const requestPushPermission = async (): Promise<boolean> => {
    if (!pushSupported) return false;

    try {
      const permission = await Notification.requestPermission();
      setPushPermission(permission);
      
      if (permission === 'granted') {
        await subscribeToPushNotifications();
        return true;
      }
      return false;
    } catch (error) {
      console.error('Failed to request push permission:', error);
      return false;
    }
  };

  const subscribeToPushNotifications = async () => {
    try {
      const registration = await navigator.serviceWorker.ready;
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(process.env.VAPID_PUBLIC_KEY || '')
      });

      // Send subscription to server
      await fetch('/api/push/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('shg_auth_token')}`
        },
        body: JSON.stringify({
          subscription,
          userId: user?.id
        })
      });

      console.log('Push notification subscription successful');
    } catch (error) {
      console.error('Failed to subscribe to push notifications:', error);
    }
  };

  const sendNotification = async (
    type: 'sms' | 'whatsapp' | 'email' | 'push',
    event: string,
    recipients: string[],
    data: Record<string, string>,
    language: string = 'en'
  ) => {
    try {
      const template = notificationTemplates[language]?.[event] || notificationTemplates.en[event];
      if (!template) {
        throw new Error(`No template found for event: ${event}`);
      }

      // Replace placeholders in template
      let message = template;
      Object.entries(data).forEach(([key, value]) => {
        message = message.replace(new RegExp(`{{${key}}}`, 'g'), value);
      });

      const payload = {
        type,
        event,
        recipients,
        message,
        data,
        language
      };

      const response = await fetch('/api/notifications/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('shg_auth_token')}`
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error('Failed to send notification');
      }

      console.log(`${type} notification sent successfully`);
      return true;
    } catch (error) {
      console.error('Failed to send notification:', error);
      return false;
    }
  };

  const sendLoanStatusNotification = async (
    memberId: string,
    loanAmount: number,
    status: 'approved' | 'rejected',
    language: string = 'en'
  ) => {
    const event = status === 'approved' ? 'loan_approved' : 'loan_rejected';
    const recipients = [memberId]; // Will be resolved to phone numbers on server
    
    const data = {
      amount: loanAmount.toString(),
      date: new Date().toLocaleDateString()
    };

    if (preferences.smsEnabled) {
      await sendNotification('sms', event, recipients, data, language);
    }

    if (preferences.whatsappEnabled) {
      await sendNotification('whatsapp', event, recipients, data, language);
    }

    if (preferences.pushEnabled && pushPermission === 'granted') {
      await sendNotification('push', event, recipients, data, language);
    }
  };

  const sendMeetingReminder = async (
    groupId: string,
    meetingTime: string,
    language: string = 'en'
  ) => {
    const recipients = [`group:${groupId}`]; // Server will resolve to all group members
    const data = {
      time: meetingTime,
      date: new Date().toLocaleDateString()
    };

    if (preferences.meetingAlerts) {
      if (preferences.smsEnabled) {
        await sendNotification('sms', 'meeting_reminder', recipients, data, language);
      }

      if (preferences.whatsappEnabled) {
        await sendNotification('whatsapp', 'meeting_reminder', recipients, data, language);
      }

      if (preferences.pushEnabled) {
        await sendNotification('push', 'meeting_reminder', recipients, data, language);
      }
    }
  };

  const sendSavingsReminder = async (
    memberId: string,
    amount: number,
    dueDate: string,
    language: string = 'en'
  ) => {
    const recipients = [memberId];
    const data = {
      amount: amount.toString(),
      date: dueDate
    };

    if (preferences.savingsReminders) {
      if (preferences.smsEnabled) {
        await sendNotification('sms', 'savings_reminder', recipients, data, language);
      }

      if (preferences.whatsappEnabled) {
        await sendNotification('whatsapp', 'savings_reminder', recipients, data, language);
      }

      if (preferences.pushEnabled) {
        await sendNotification('push', 'savings_reminder', recipients, data, language);
      }
    }
  };

  const sendPollNotification = async (
    groupId: string,
    pollTitle: string,
    deadline: string,
    language: string = 'en'
  ) => {
    const recipients = [`group:${groupId}`];
    const data = {
      title: pollTitle,
      deadline: deadline
    };

    if (preferences.pollNotifications) {
      if (preferences.smsEnabled) {
        await sendNotification('sms', 'poll_created', recipients, data, language);
      }

      if (preferences.whatsappEnabled) {
        await sendNotification('whatsapp', 'poll_created', recipients, data, language);
      }

      if (preferences.pushEnabled) {
        await sendNotification('push', 'poll_created', recipients, data, language);
      }
    }
  };

  return {
    preferences,
    savePreferences,
    pushSupported,
    pushPermission,
    requestPushPermission,
    sendLoanStatusNotification,
    sendMeetingReminder,
    sendSavingsReminder,
    sendPollNotification,
    sendNotification
  };
}

// Helper function to convert VAPID key
function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding)
    .replace(/-/g, '+')
    .replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}