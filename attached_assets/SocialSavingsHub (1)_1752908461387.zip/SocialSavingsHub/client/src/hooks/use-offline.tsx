import { useState, useEffect } from "react";

export interface OfflineData {
  savingsDeposits: any[];
  loanApplications: any[];
  pollVotes: any[];
  lastSync: Date | null;
}

export function useOffline() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [pendingSync, setPendingSync] = useState<OfflineData>({
    savingsDeposits: [],
    loanApplications: [],
    pollVotes: [],
    lastSync: null
  });

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      syncPendingData();
    };

    const handleOffline = () => {
      setIsOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Initialize IndexedDB
    initializeOfflineDB();

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const initializeOfflineDB = () => {
    const request = indexedDB.open('SHGPlatformDB', 1);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;

      // Create object stores for offline data
      if (!db.objectStoreNames.contains('pendingSavings')) {
        const savingsStore = db.createObjectStore('pendingSavings', { keyPath: 'id', autoIncrement: true });
        savingsStore.createIndex('timestamp', 'timestamp', { unique: false });
      }

      if (!db.objectStoreNames.contains('pendingLoans')) {
        const loansStore = db.createObjectStore('pendingLoans', { keyPath: 'id', autoIncrement: true });
        loansStore.createIndex('timestamp', 'timestamp', { unique: false });
      }

      if (!db.objectStoreNames.contains('pendingVotes')) {
        const votesStore = db.createObjectStore('pendingVotes', { keyPath: 'id', autoIncrement: true });
        votesStore.createIndex('timestamp', 'timestamp', { unique: false });
      }

      if (!db.objectStoreNames.contains('cachedData')) {
        const cacheStore = db.createObjectStore('cachedData', { keyPath: 'key' });
      }
    };
  };

  const addToOfflineQueue = async (type: 'savings' | 'loans' | 'votes', data: any) => {
    const storeName = type === 'savings' ? 'pendingSavings' : 
                     type === 'loans' ? 'pendingLoans' : 'pendingVotes';

    return new Promise<void>((resolve, reject) => {
      const request = indexedDB.open('SHGPlatformDB', 1);

      request.onsuccess = () => {
        const db = request.result;
        const transaction = db.transaction([storeName], 'readwrite');
        const store = transaction.objectStore(storeName);

        const item = {
          data,
          timestamp: new Date(),
          authToken: localStorage.getItem('shg_auth_token')
        };

        const addRequest = store.add(item);

        addRequest.onsuccess = () => {
          console.log(`Added ${type} to offline queue`);
          updatePendingSync();
          resolve();
        };

        addRequest.onerror = () => {
          reject(addRequest.error);
        };
      };

      request.onerror = () => {
        reject(request.error);
      };
    });
  };

  const updatePendingSync = async () => {
    try {
      const savings = await getFromIndexedDB('pendingSavings');
      const loans = await getFromIndexedDB('pendingLoans');
      const votes = await getFromIndexedDB('pendingVotes');

      setPendingSync({
        savingsDeposits: savings,
        loanApplications: loans,
        pollVotes: votes,
        lastSync: new Date()
      });
    } catch (error) {
      console.error('Failed to update pending sync data:', error);
    }
  };

  const syncPendingData = async () => {
    if (!isOnline) return;

    try {
      // Register background sync
      if ('serviceWorker' in navigator && 'sync' in window.ServiceWorkerRegistration.prototype) {
        const registration = await navigator.serviceWorker.ready;
        await registration.sync.register('background-sync');
        console.log('Background sync registered');
      }
    } catch (error) {
      console.error('Failed to register background sync:', error);
    }
  };

  const getFromIndexedDB = (storeName: string): Promise<any[]> => {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('SHGPlatformDB', 1);

      request.onsuccess = () => {
        const db = request.result;
        const transaction = db.transaction([storeName], 'readonly');
        const store = transaction.objectStore(storeName);
        const getAllRequest = store.getAll();

        getAllRequest.onsuccess = () => {
          resolve(getAllRequest.result || []);
        };

        getAllRequest.onerror = () => {
          reject(getAllRequest.error);
        };
      };

      request.onerror = () => {
        reject(request.error);
      };
    });
  };

  const cacheData = async (key: string, data: any) => {
    return new Promise<void>((resolve, reject) => {
      const request = indexedDB.open('SHGPlatformDB', 1);

      request.onsuccess = () => {
        const db = request.result;
        const transaction = db.transaction(['cachedData'], 'readwrite');
        const store = transaction.objectStore('cachedData');

        const item = {
          key,
          data,
          timestamp: new Date()
        };

        const putRequest = store.put(item);

        putRequest.onsuccess = () => {
          resolve();
        };

        putRequest.onerror = () => {
          reject(putRequest.error);
        };
      };

      request.onerror = () => {
        reject(request.error);
      };
    });
  };

  const getCachedData = async (key: string): Promise<any> => {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('SHGPlatformDB', 1);

      request.onsuccess = () => {
        const db = request.result;
        const transaction = db.transaction(['cachedData'], 'readonly');
        const store = transaction.objectStore('cachedData');
        const getRequest = store.get(key);

        getRequest.onsuccess = () => {
          const result = getRequest.result;
          resolve(result ? result.data : null);
        };

        getRequest.onerror = () => {
          reject(getRequest.error);
        };
      };

      request.onerror = () => {
        reject(request.error);
      };
    });
  };

  return {
    isOnline,
    pendingSync,
    addToOfflineQueue,
    syncPendingData,
    cacheData,
    getCachedData
  };
}