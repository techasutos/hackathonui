import { createContext, useContext, useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import {
  getAuthToken,
  setAuthToken,
  removeAuthToken,
  getStoredUser,
  setStoredUser,
  getStoredMember,
  setStoredMember,
} from "@/lib/auth";
import { AuthResponse } from "@/types/api";
import { LoginRequest } from "@shared/schema";

interface AuthContextType {
  user: AuthResponse["user"] | null;
  member: AuthResponse["member"] | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (credentials: LoginRequest) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthResponse["user"] | null>(getStoredUser());
  const [member, setMember] = useState<AuthResponse["member"] | null>(getStoredMember());
  const [isLoading, setIsLoading] = useState(true);
  const queryClient = useQueryClient();

  const isAuthenticated = !!user && !!getAuthToken();

  useEffect(() => {
    // Check if we have a valid token and user data on app start
    const token = getAuthToken();
    const storedUser = getStoredUser();
    
    if (token && storedUser) {
      setUser(storedUser);
      setMember(getStoredMember());
    }
    
    setIsLoading(false);
  }, []);

  const loginMutation = useMutation({
    mutationFn: async (credentials: LoginRequest): Promise<AuthResponse> => {
      const response = await apiRequest("POST", "/api/auth/login", credentials);
      return response.json();
    },
    onSuccess: (data: AuthResponse) => {
      setAuthToken(data.token);
      setStoredUser(data.user);
      setStoredMember(data.member);
      setUser(data.user);
      setMember(data.member);
      queryClient.invalidateQueries();
    },
  });

  const login = async (credentials: LoginRequest) => {
    await loginMutation.mutateAsync(credentials);
  };

  const logout = () => {
    removeAuthToken();
    setUser(null);
    setMember(null);
    queryClient.clear();
  };

  const value = {
    user,
    member,
    isAuthenticated,
    isLoading: isLoading || loginMutation.isPending,
    login,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
