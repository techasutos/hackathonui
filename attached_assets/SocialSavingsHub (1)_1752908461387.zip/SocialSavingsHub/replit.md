# SHG Digital Platform - Technical Documentation

## Overview

This is a comprehensive Self Help Group (SHG) digital platform built with modern web technologies. The application enables digital management of savings groups with features for member management, loan processing, savings tracking, governance through polling, SDG impact monitoring, and CSR proposal management.

**Recent Major Updates (July 2025):**
- Enhanced landing page with testimonials, footer, and SVG illustrations
- Multi-language support for 12+ regional Indian languages
- Progressive Web App (PWA) capabilities with offline functionality
- Advanced reporting and custom dashboard creation
- SMS/WhatsApp notification integration with multi-language templates
- Modern navbar with burger menu and gradient login button
- Background data synchronization for offline operations

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight client-side routing)
- **State Management**: TanStack Query (React Query) for server state
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Build Tool**: Vite with custom configuration for development and production

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Authentication**: JWT-based with role-based access control
- **API Design**: RESTful endpoints with structured error handling

### Key Design Decisions
- **Monorepo Structure**: Single repository with shared schema between client and server
- **Type Safety**: End-to-end TypeScript with shared types via `@shared` imports
- **Component Architecture**: Composition-based UI with reusable components and hooks
- **Form Handling**: React Hook Form with Zod validation for type-safe forms

## Key Components

### Authentication & Authorization
- JWT token-based authentication with localStorage persistence
- Role-based access control (MEMBER, TREASURER, PRESIDENT, ADMIN)
- Protected routes using AuthGuard component
- Session management with automatic token validation

### Database Schema
The application uses Drizzle ORM with the following main entities:
- **Users**: Authentication and basic user data
- **Groups**: Self-help group management with financial tracking
- **Members**: Extended member profiles linked to users and groups
- **SavingDeposits**: Individual savings transactions
- **LoanApplications**: Loan lifecycle management
- **Polls**: Democratic governance features
- **SDGImpacts**: Sustainable Development Goals tracking
- **CSRProposals**: Corporate Social Responsibility proposals

### UI Components
- Consistent design system using shadcn/ui
- Responsive design with mobile-first approach
- Accessible components with proper ARIA attributes
- Theme support with CSS custom properties

## Data Flow

### Client-Server Communication
1. **API Requests**: Centralized through `apiRequest` utility with error handling
2. **State Management**: TanStack Query for caching, synchronization, and background updates
3. **Authentication Flow**: JWT tokens included in requests, automatic logout on 401 responses
4. **Form Submissions**: React Hook Form → Zod validation → API mutation → UI updates

### State Management Strategy
- **Server State**: Managed by TanStack Query with automatic caching
- **Client State**: React useState and useContext for local component state
- **Authentication State**: Persistent state with localStorage synchronization
- **Form State**: React Hook Form for complex form management

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connectivity
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI primitives
- **drizzle-orm**: Type-safe database ORM
- **zod**: Runtime type validation
- **react-hook-form**: Form state management
- **wouter**: Lightweight routing

### Development Dependencies
- **Vite**: Build tool and development server
- **TypeScript**: Type checking and compilation
- **Tailwind CSS**: Utility-first CSS framework
- **ESLint/Prettier**: Code quality and formatting

## Deployment Strategy

### Build Process
1. **Frontend Build**: Vite compiles React app to static assets in `dist/public`
2. **Backend Build**: esbuild bundles server code to `dist/index.js`
3. **Database**: Drizzle migrations in `migrations/` directory
4. **Environment**: Environment variables for database connection and JWT secrets

### Production Configuration
- **Server**: Node.js application serving static files and API routes
- **Database**: PostgreSQL with connection pooling
- **Security**: JWT secret management, CORS configuration
- **Performance**: Static asset serving with proper caching headers

### Development Workflow
- **Hot Reload**: Vite dev server with HMR for frontend changes
- **API Development**: tsx with file watching for backend changes
- **Database**: Drizzle Kit for schema management and migrations
- **Type Safety**: Shared types between frontend and backend

## Special Features

### Role-Based Access Control
The application implements a sophisticated permission system where different user roles have access to different features:
- Members can manage their own savings and apply for loans
- Treasurers can disburse approved loans
- Presidents can approve loan applications and create polls
- Admins have full system access

### Real-time Financial Tracking
Group funds are automatically updated when:
- Members make savings deposits
- Loans are disbursed
- Loan repayments are processed
- Profit/loss calculations are performed

### SDG Impact Monitoring
The platform automatically tracks progress toward Sustainable Development Goals by monitoring group activities and their social impact metrics.

### Mobile-First Design
The application is built with a responsive design that works seamlessly across desktop, tablet, and mobile devices with specific mobile navigation patterns.

### Advanced Features (Recently Added)

#### Multi-Language Support
- Support for 12+ regional languages including Hindi, Bengali, Tamil, Telugu, Marathi, Gujarati, Kannada, Malayalam, Punjabi, Odia, and Assamese
- Context-aware translation system with React Context API
- Language selector component with compact and full variants
- Browser language detection with localStorage persistence
- RTL language support for Arabic/Urdu if needed in future

#### Progressive Web App (PWA) Capabilities
- Service Worker registration for offline functionality
- IndexedDB for offline data storage and background sync
- App manifest with shortcuts and install prompts
- Automatic data synchronization when connection restored
- Native app-like experience with installation prompts

#### Advanced Reporting & Analytics
- Custom dashboard builder with drag-and-drop widgets
- Report builder with templates and filters
- Real-time analytics with Recharts visualizations
- AI-powered insights and recommendations
- Export capabilities for multiple formats
- Public/private report sharing

#### SMS/WhatsApp Notification System
- Multi-channel notification support (SMS, WhatsApp, Email, Push)
- Template-based messaging with parameter substitution
- Language-specific notification templates
- Event-driven notifications for loan status, meetings, savings reminders
- User preference management for notification types
- Push notification subscription management

#### Enhanced Landing Page
- Testimonials section with real user stories
- SVG illustrations depicting rural Indian village scenes
- Comprehensive footer with contact information and social links
- Advanced features showcase section
- Modern UI with gradient effects and animations

#### Offline-First Architecture
- Background sync for pending transactions
- Cached data retrieval during offline periods
- Offline indicator showing sync status
- Queue management for offline operations
- Automatic retry mechanisms for failed sync operations