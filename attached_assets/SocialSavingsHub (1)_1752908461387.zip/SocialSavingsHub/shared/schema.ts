import { pgTable, text, serial, integer, boolean, timestamp, decimal, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users and Authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  role: text("role").notNull().default("MEMBER"), // MEMBER, TREASURER, PRESIDENT, ADMIN
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Groups
export const groups = pgTable("groups", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  totalBalance: decimal("total_balance", { precision: 12, scale: 2 }).notNull().default("0"),
  totalProfit: decimal("total_profit", { precision: 12, scale: 2 }).notNull().default("0"),
  totalLoss: decimal("total_loss", { precision: 12, scale: 2 }).notNull().default("0"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

// Members
export const members = pgTable("members", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  groupId: integer("group_id").references(() => groups.id),
  name: text("name").notNull(),
  aadhaar: text("aadhaar").notNull().unique(),
  gender: text("gender").notNull(),
  phone: text("phone").notNull(),
  isApproved: boolean("is_approved").notNull().default(false),
  joinedAt: timestamp("joined_at").notNull().defaultNow(),
});

// Savings Deposits
export const savingDeposits = pgTable("saving_deposits", {
  id: serial("id").primaryKey(),
  memberId: integer("member_id").references(() => members.id),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  remarks: text("remarks"),
  depositDate: timestamp("deposit_date").notNull().defaultNow(),
});

// Loan Applications
export const loanApplications = pgTable("loan_applications", {
  id: serial("id").primaryKey(),
  memberId: integer("member_id").references(() => members.id),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  purpose: text("purpose").notNull(),
  description: text("description"),
  repaymentPeriod: integer("repayment_period").notNull(), // in months
  status: text("status").notNull().default("PENDING"), // PENDING, APPROVED, DISBURSED, REPAID, REJECTED
  appliedAt: timestamp("applied_at").notNull().defaultNow(),
  approvedAt: timestamp("approved_at"),
  disbursedAt: timestamp("disbursed_at"),
});

// Loan Repayments
export const loanRepayments = pgTable("loan_repayments", {
  id: serial("id").primaryKey(),
  loanId: integer("loan_id").references(() => loanApplications.id),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  repaidAt: timestamp("repaid_at").notNull().defaultNow(),
});

// Polls
export const polls = pgTable("polls", {
  id: serial("id").primaryKey(),
  groupId: integer("group_id").references(() => groups.id),
  title: text("title").notNull(),
  description: text("description"),
  options: json("options").notNull(), // Array of option objects
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  closedAt: timestamp("closed_at"),
});

// Poll Votes
export const pollVotes = pgTable("poll_votes", {
  id: serial("id").primaryKey(),
  pollId: integer("poll_id").references(() => polls.id),
  memberId: integer("member_id").references(() => members.id),
  selectedOption: text("selected_option").notNull(),
  votedAt: timestamp("voted_at").notNull().defaultNow(),
});

// SDG Impact Tracking
export const sdgImpacts = pgTable("sdg_impacts", {
  id: serial("id").primaryKey(),
  groupId: integer("group_id").references(() => groups.id),
  goalNumber: integer("goal_number").notNull(),
  goalTitle: text("goal_title").notNull(),
  impactScore: integer("impact_score").notNull().default(0), // 0-100
  jobsCreated: integer("jobs_created").notNull().default(0),
  womenEmpowered: integer("women_empowered").notNull().default(0),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

// CSR Proposals
export const csrProposals = pgTable("csr_proposals", {
  id: serial("id").primaryKey(),
  groupId: integer("group_id").references(() => groups.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  requestedAmount: decimal("requested_amount", { precision: 12, scale: 2 }).notNull(),
  sdgGoals: json("sdg_goals").notNull(), // Array of SDG goal numbers
  status: text("status").notNull().default("DRAFT"), // DRAFT, SUBMITTED, UNDER_REVIEW, APPROVED, REJECTED
  submittedAt: timestamp("submitted_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertGroupSchema = createInsertSchema(groups).omit({
  id: true,
  createdAt: true,
  lastUpdated: true,
});

export const insertMemberSchema = createInsertSchema(members).omit({
  id: true,
  joinedAt: true,
});

export const insertSavingDepositSchema = createInsertSchema(savingDeposits).omit({
  id: true,
  depositDate: true,
});

export const insertLoanApplicationSchema = createInsertSchema(loanApplications).omit({
  id: true,
  appliedAt: true,
  approvedAt: true,
  disbursedAt: true,
});

export const insertPollSchema = createInsertSchema(polls).omit({
  id: true,
  createdAt: true,
  closedAt: true,
});

export const insertCSRProposalSchema = createInsertSchema(csrProposals).omit({
  id: true,
  createdAt: true,
  submittedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Group = typeof groups.$inferSelect;
export type InsertGroup = z.infer<typeof insertGroupSchema>;
export type Member = typeof members.$inferSelect;
export type InsertMember = z.infer<typeof insertMemberSchema>;
export type SavingDeposit = typeof savingDeposits.$inferSelect;
export type InsertSavingDeposit = z.infer<typeof insertSavingDepositSchema>;
export type LoanApplication = typeof loanApplications.$inferSelect;
export type InsertLoanApplication = z.infer<typeof insertLoanApplicationSchema>;
export type LoanRepayment = typeof loanRepayments.$inferSelect;
export type Poll = typeof polls.$inferSelect;
export type InsertPoll = z.infer<typeof insertPollSchema>;
export type PollVote = typeof pollVotes.$inferSelect;
export type SDGImpact = typeof sdgImpacts.$inferSelect;
export type CSRProposal = typeof csrProposals.$inferSelect;
export type InsertCSRProposal = z.infer<typeof insertCSRProposalSchema>;

// Auth schemas
export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export type LoginRequest = z.infer<typeof loginSchema>;
