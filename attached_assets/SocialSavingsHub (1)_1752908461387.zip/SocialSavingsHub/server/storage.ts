import {
  users, groups, members, savingDeposits, loanApplications, loanRepayments,
  polls, pollVotes, sdgImpacts, csrProposals,
  type User, type InsertUser, type Group, type InsertGroup,
  type Member, type InsertMember, type SavingDeposit, type InsertSavingDeposit,
  type LoanApplication, type InsertLoanApplication, type LoanRepayment,
  type Poll, type InsertPoll, type PollVote, type SDGImpact, type CSRProposal, type InsertCSRProposal
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Groups
  getGroup(id: number): Promise<Group | undefined>;
  getAllGroups(): Promise<Group[]>;
  createGroup(group: InsertGroup): Promise<Group>;
  updateGroup(id: number, group: Partial<Group>): Promise<Group | undefined>;
  
  // Members
  getMember(id: number): Promise<Member | undefined>;
  getMembersByGroup(groupId: number): Promise<Member[]>;
  getMemberByUserId(userId: number): Promise<Member | undefined>;
  createMember(member: InsertMember): Promise<Member>;
  updateMember(id: number, member: Partial<Member>): Promise<Member | undefined>;
  
  // Savings
  getSavingDeposit(id: number): Promise<SavingDeposit | undefined>;
  getSavingDepositsByMember(memberId: number): Promise<SavingDeposit[]>;
  getSavingDepositsByGroup(groupId: number): Promise<SavingDeposit[]>;
  createSavingDeposit(deposit: InsertSavingDeposit): Promise<SavingDeposit>;
  
  // Loans
  getLoanApplication(id: number): Promise<LoanApplication | undefined>;
  getLoanApplicationsByMember(memberId: number): Promise<LoanApplication[]>;
  getLoanApplicationsByGroup(groupId: number): Promise<LoanApplication[]>;
  createLoanApplication(loan: InsertLoanApplication): Promise<LoanApplication>;
  updateLoanApplication(id: number, loan: Partial<LoanApplication>): Promise<LoanApplication | undefined>;
  getLoanRepayments(loanId: number): Promise<LoanRepayment[]>;
  createLoanRepayment(repayment: Omit<LoanRepayment, 'id'>): Promise<LoanRepayment>;
  
  // Polls
  getPoll(id: number): Promise<Poll | undefined>;
  getPollsByGroup(groupId: number): Promise<Poll[]>;
  createPoll(poll: InsertPoll): Promise<Poll>;
  updatePoll(id: number, poll: Partial<Poll>): Promise<Poll | undefined>;
  getPollVotes(pollId: number): Promise<PollVote[]>;
  createPollVote(vote: Omit<PollVote, 'id'>): Promise<PollVote>;
  
  // SDG Impact
  getSDGImpacts(groupId: number): Promise<SDGImpact[]>;
  updateSDGImpact(groupId: number, goalNumber: number, impact: Partial<SDGImpact>): Promise<SDGImpact>;
  
  // CSR Proposals
  getCSRProposal(id: number): Promise<CSRProposal | undefined>;
  getCSRProposalsByGroup(groupId: number): Promise<CSRProposal[]>;
  createCSRProposal(proposal: InsertCSRProposal): Promise<CSRProposal>;
  updateCSRProposal(id: number, proposal: Partial<CSRProposal>): Promise<CSRProposal | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private groups: Map<number, Group> = new Map();
  private members: Map<number, Member> = new Map();
  private savingDeposits: Map<number, SavingDeposit> = new Map();
  private loanApplications: Map<number, LoanApplication> = new Map();
  private loanRepayments: Map<number, LoanRepayment> = new Map();
  private polls: Map<number, Poll> = new Map();
  private pollVotes: Map<number, PollVote> = new Map();
  private sdgImpacts: Map<string, SDGImpact> = new Map(); // key: `${groupId}-${goalNumber}`
  private csrProposals: Map<number, CSRProposal> = new Map();
  
  private currentUserId = 1;
  private currentGroupId = 1;
  private currentMemberId = 1;
  private currentDepositId = 1;
  private currentLoanId = 1;
  private currentRepaymentId = 1;
  private currentPollId = 1;
  private currentVoteId = 1;
  private currentImpactId = 1;
  private currentProposalId = 1;

  constructor() {
    this.seedData();
  }

  private seedData() {
    // Seed admin user
    const adminUser: User = {
      id: this.currentUserId++,
      username: "admin",
      password: "admin123", // In real app, this would be hashed
      email: "admin@shg.com",
      role: "ADMIN",
      isActive: true,
      createdAt: new Date(),
    };
    this.users.set(adminUser.id, adminUser);

    // Seed test group
    const testGroup: Group = {
      id: this.currentGroupId++,
      name: "Shakti Women's Group",
      description: "A self-help group focused on women empowerment and financial inclusion",
      totalBalance: "25000.00",
      totalProfit: "2500.00",
      totalLoss: "500.00",
      createdAt: new Date(),
      lastUpdated: new Date(),
    };
    this.groups.set(testGroup.id, testGroup);

    // Seed test member
    const testMember: Member = {
      id: this.currentMemberId++,
      userId: adminUser.id,
      groupId: testGroup.id,
      name: "Priya Sharma",
      aadhaar: "1234-5678-9012",
      gender: "Female",
      phone: "+91-9876543210",
      isApproved: true,
      joinedAt: new Date(),
    };
    this.members.set(testMember.id, testMember);

    // Seed SDG impacts
    const sdgGoals = [
      { number: 1, title: "No Poverty", score: 75 },
      { number: 5, title: "Gender Equality", score: 90 },
      { number: 8, title: "Decent Work and Economic Growth", score: 65 },
      { number: 10, title: "Reduced Inequalities", score: 80 },
    ];

    sdgGoals.forEach(goal => {
      const impact: SDGImpact = {
        id: this.currentImpactId++,
        groupId: testGroup.id,
        goalNumber: goal.number,
        goalTitle: goal.title,
        impactScore: goal.score,
        jobsCreated: Math.floor(Math.random() * 10) + 1,
        womenEmpowered: Math.floor(Math.random() * 20) + 10,
        lastUpdated: new Date(),
      };
      this.sdgImpacts.set(`${testGroup.id}-${goal.number}`, impact);
    });
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = {
      ...insertUser,
      id: this.currentUserId++,
      role: insertUser.role || 'MEMBER',
      isActive: insertUser.isActive !== undefined ? insertUser.isActive : true,
      createdAt: new Date(),
    };
    this.users.set(user.id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Groups
  async getGroup(id: number): Promise<Group | undefined> {
    return this.groups.get(id);
  }

  async getAllGroups(): Promise<Group[]> {
    return Array.from(this.groups.values());
  }

  async createGroup(insertGroup: InsertGroup): Promise<Group> {
    const group: Group = {
      ...insertGroup,
      id: this.currentGroupId++,
      description: insertGroup.description ?? null,
      totalBalance: insertGroup.totalBalance || "0",
      totalProfit: insertGroup.totalProfit || "0",
      totalLoss: insertGroup.totalLoss || "0",
      createdAt: new Date(),
      lastUpdated: new Date(),
    };
    this.groups.set(group.id, group);
    return group;
  }

  async updateGroup(id: number, updates: Partial<Group>): Promise<Group | undefined> {
    const group = this.groups.get(id);
    if (!group) return undefined;
    
    const updatedGroup = { ...group, ...updates, lastUpdated: new Date() };
    this.groups.set(id, updatedGroup);
    return updatedGroup;
  }

  // Members
  async getMember(id: number): Promise<Member | undefined> {
    return this.members.get(id);
  }

  async getMembersByGroup(groupId: number): Promise<Member[]> {
    return Array.from(this.members.values()).filter(member => member.groupId === groupId);
  }

  async getMemberByUserId(userId: number): Promise<Member | undefined> {
    return Array.from(this.members.values()).find(member => member.userId === userId);
  }

  async createMember(insertMember: InsertMember): Promise<Member> {
    const member: Member = {
      ...insertMember,
      id: this.currentMemberId++,
      userId: insertMember.userId ?? null,
      groupId: insertMember.groupId ?? null,
      isApproved: insertMember.isApproved !== undefined ? insertMember.isApproved : false,
      joinedAt: new Date(),
    };
    this.members.set(member.id, member);
    return member;
  }

  async updateMember(id: number, updates: Partial<Member>): Promise<Member | undefined> {
    const member = this.members.get(id);
    if (!member) return undefined;
    
    const updatedMember = { ...member, ...updates };
    this.members.set(id, updatedMember);
    return updatedMember;
  }

  // Savings
  async getSavingDeposit(id: number): Promise<SavingDeposit | undefined> {
    return this.savingDeposits.get(id);
  }

  async getSavingDepositsByMember(memberId: number): Promise<SavingDeposit[]> {
    return Array.from(this.savingDeposits.values()).filter(deposit => deposit.memberId === memberId);
  }

  async getSavingDepositsByGroup(groupId: number): Promise<SavingDeposit[]> {
    const groupMembers = await this.getMembersByGroup(groupId);
    const memberIds = groupMembers.map(member => member.id);
    return Array.from(this.savingDeposits.values()).filter(deposit => 
      deposit.memberId && memberIds.includes(deposit.memberId)
    );
  }

  async createSavingDeposit(insertDeposit: InsertSavingDeposit): Promise<SavingDeposit> {
    const deposit: SavingDeposit = {
      ...insertDeposit,
      id: this.currentDepositId++,
      memberId: insertDeposit.memberId ?? null,
      remarks: insertDeposit.remarks ?? null,
      depositDate: new Date(),
    };
    this.savingDeposits.set(deposit.id, deposit);
    return deposit;
  }

  // Loans
  async getLoanApplication(id: number): Promise<LoanApplication | undefined> {
    return this.loanApplications.get(id);
  }

  async getLoanApplicationsByMember(memberId: number): Promise<LoanApplication[]> {
    return Array.from(this.loanApplications.values()).filter(loan => loan.memberId === memberId);
  }

  async getLoanApplicationsByGroup(groupId: number): Promise<LoanApplication[]> {
    const groupMembers = await this.getMembersByGroup(groupId);
    const memberIds = groupMembers.map(member => member.id);
    return Array.from(this.loanApplications.values()).filter(loan => 
      loan.memberId && memberIds.includes(loan.memberId)
    );
  }

  async createLoanApplication(insertLoan: InsertLoanApplication): Promise<LoanApplication> {
    const loan: LoanApplication = {
      ...insertLoan,
      id: this.currentLoanId++,
      status: insertLoan.status || 'PENDING',
      description: insertLoan.description ?? null,
      memberId: insertLoan.memberId ?? null,
      appliedAt: new Date(),
      approvedAt: null,
      disbursedAt: null,
    };
    this.loanApplications.set(loan.id, loan);
    return loan;
  }

  async updateLoanApplication(id: number, updates: Partial<LoanApplication>): Promise<LoanApplication | undefined> {
    const loan = this.loanApplications.get(id);
    if (!loan) return undefined;
    
    const updatedLoan = { ...loan, ...updates };
    this.loanApplications.set(id, updatedLoan);
    return updatedLoan;
  }

  async getLoanRepayments(loanId: number): Promise<LoanRepayment[]> {
    return Array.from(this.loanRepayments.values()).filter(repayment => repayment.loanId === loanId);
  }

  async createLoanRepayment(repayment: Omit<LoanRepayment, 'id'>): Promise<LoanRepayment> {
    const newRepayment: LoanRepayment = {
      ...repayment,
      id: this.currentRepaymentId++,
    };
    this.loanRepayments.set(newRepayment.id, newRepayment);
    return newRepayment;
  }

  // Polls
  async getPoll(id: number): Promise<Poll | undefined> {
    return this.polls.get(id);
  }

  async getPollsByGroup(groupId: number): Promise<Poll[]> {
    return Array.from(this.polls.values()).filter(poll => poll.groupId === groupId);
  }

  async createPoll(insertPoll: InsertPoll): Promise<Poll> {
    const poll: Poll = {
      ...insertPoll,
      id: this.currentPollId++,
      description: insertPoll.description ?? null,
      groupId: insertPoll.groupId ?? null,
      isActive: insertPoll.isActive !== undefined ? insertPoll.isActive : true,
      createdAt: new Date(),
      closedAt: null,
    };
    this.polls.set(poll.id, poll);
    return poll;
  }

  async updatePoll(id: number, updates: Partial<Poll>): Promise<Poll | undefined> {
    const poll = this.polls.get(id);
    if (!poll) return undefined;
    
    const updatedPoll = { ...poll, ...updates };
    this.polls.set(id, updatedPoll);
    return updatedPoll;
  }

  async getPollVotes(pollId: number): Promise<PollVote[]> {
    return Array.from(this.pollVotes.values()).filter(vote => vote.pollId === pollId);
  }

  async createPollVote(vote: Omit<PollVote, 'id'>): Promise<PollVote> {
    const newVote: PollVote = {
      ...vote,
      id: this.currentVoteId++,
    };
    this.pollVotes.set(newVote.id, newVote);
    return newVote;
  }

  // SDG Impact
  async getSDGImpacts(groupId: number): Promise<SDGImpact[]> {
    return Array.from(this.sdgImpacts.values()).filter(impact => impact.groupId === groupId);
  }

  async updateSDGImpact(groupId: number, goalNumber: number, updates: Partial<SDGImpact>): Promise<SDGImpact> {
    const key = `${groupId}-${goalNumber}`;
    const existing = this.sdgImpacts.get(key);
    
    const impact: SDGImpact = {
      id: existing?.id || this.currentImpactId++,
      groupId,
      goalNumber,
      goalTitle: updates.goalTitle || existing?.goalTitle || `SDG ${goalNumber}`,
      impactScore: updates.impactScore || existing?.impactScore || 0,
      jobsCreated: updates.jobsCreated || existing?.jobsCreated || 0,
      womenEmpowered: updates.womenEmpowered || existing?.womenEmpowered || 0,
      lastUpdated: new Date(),
      ...updates,
    };
    
    this.sdgImpacts.set(key, impact);
    return impact;
  }

  // CSR Proposals
  async getCSRProposal(id: number): Promise<CSRProposal | undefined> {
    return this.csrProposals.get(id);
  }

  async getCSRProposalsByGroup(groupId: number): Promise<CSRProposal[]> {
    return Array.from(this.csrProposals.values()).filter(proposal => proposal.groupId === groupId);
  }

  async createCSRProposal(insertProposal: InsertCSRProposal): Promise<CSRProposal> {
    const proposal: CSRProposal = {
      ...insertProposal,
      id: this.currentProposalId++,
      status: insertProposal.status || 'DRAFT',
      groupId: insertProposal.groupId ?? null,
      createdAt: new Date(),
      submittedAt: null,
    };
    this.csrProposals.set(proposal.id, proposal);
    return proposal;
  }

  async updateCSRProposal(id: number, updates: Partial<CSRProposal>): Promise<CSRProposal | undefined> {
    const proposal = this.csrProposals.get(id);
    if (!proposal) return undefined;
    
    const updatedProposal = { ...proposal, ...updates };
    this.csrProposals.set(id, updatedProposal);
    return updatedProposal;
  }
}

export const storage = new MemStorage();
