import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import { loginSchema, insertUserSchema, insertMemberSchema, insertSavingDepositSchema, insertLoanApplicationSchema, insertPollSchema, insertCSRProposalSchema } from "@shared/schema";

// Extend Express Request interface
declare global {
  namespace Express {
    interface Request {
      user?: {
        id: number;
        username: string;
        role: string;
      };
    }
  }
}

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

// JWT middleware
function authenticateToken(req: any, res: any, next: any) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.status(403).json({ message: 'Invalid token' });
    req.user = user;
    next();
  });
}

// Role-based authorization
function requireRole(roles: string[]) {
  return (req: any, res: any, next: any) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'Insufficient permissions' });
    }
    next();
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // In a real app, we'd use bcrypt.compare
      if (user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = jwt.sign(
        { id: user.id, username: user.username, role: user.role },
        JWT_SECRET,
        { expiresIn: '24h' }
      );

      const member = await storage.getMemberByUserId(user.id);

      res.json({
        token,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          role: user.role,
        },
        member: member || null,
      });
    } catch (error) {
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const user = await storage.createUser(userData);
      
      res.status(201).json({
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
      });
    } catch (error) {
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  // Groups
  app.get("/api/groups", authenticateToken, async (req, res) => {
    try {
      const groups = await storage.getAllGroups();
      res.json(groups);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch groups" });
    }
  });

  app.get("/api/groups/:id", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const group = await storage.getGroup(id);
      
      if (!group) {
        return res.status(404).json({ message: "Group not found" });
      }
      
      res.json(group);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch group" });
    }
  });

  // Members
  app.get("/api/members", authenticateToken, async (req, res) => {
    try {
      const { groupId } = req.query;
      
      if (groupId) {
        const members = await storage.getMembersByGroup(parseInt(groupId as string));
        res.json(members);
      } else {
        res.status(400).json({ message: "Group ID is required" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch members" });
    }
  });

  app.post("/api/members", authenticateToken, async (req, res) => {
    try {
      const memberData = insertMemberSchema.parse(req.body);
      const member = await storage.createMember(memberData);
      res.status(201).json(member);
    } catch (error) {
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  app.put("/api/members/:id", authenticateToken, requireRole(['ADMIN', 'PRESIDENT']), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const member = await storage.updateMember(id, updates);
      
      if (!member) {
        return res.status(404).json({ message: "Member not found" });
      }
      
      res.json(member);
    } catch (error) {
      res.status(500).json({ message: "Failed to update member" });
    }
  });

  // Savings
  app.get("/api/savings", authenticateToken, async (req, res) => {
    try {
      const { memberId, groupId } = req.query;
      
      if (memberId) {
        const deposits = await storage.getSavingDepositsByMember(parseInt(memberId as string));
        res.json(deposits);
      } else if (groupId) {
        const deposits = await storage.getSavingDepositsByGroup(parseInt(groupId as string));
        res.json(deposits);
      } else {
        res.status(400).json({ message: "Member ID or Group ID is required" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch savings" });
    }
  });

  app.post("/api/savings", authenticateToken, async (req, res) => {
    try {
      const depositData = insertSavingDepositSchema.parse(req.body);
      const deposit = await storage.createSavingDeposit(depositData);
      res.status(201).json(deposit);
    } catch (error) {
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  // Loans
  app.get("/api/loans", authenticateToken, async (req, res) => {
    try {
      const { memberId, groupId } = req.query;
      
      if (memberId) {
        const loans = await storage.getLoanApplicationsByMember(parseInt(memberId as string));
        res.json(loans);
      } else if (groupId) {
        const loans = await storage.getLoanApplicationsByGroup(parseInt(groupId as string));
        res.json(loans);
      } else {
        res.status(400).json({ message: "Member ID or Group ID is required" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch loans" });
    }
  });

  app.post("/api/loans", authenticateToken, async (req, res) => {
    try {
      const loanData = insertLoanApplicationSchema.parse(req.body);
      const loan = await storage.createLoanApplication(loanData);
      res.status(201).json(loan);
    } catch (error) {
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  app.put("/api/loans/:id", authenticateToken, requireRole(['ADMIN', 'PRESIDENT', 'TREASURER']), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      // Add timestamps for status changes
      if (updates.status === 'APPROVED') {
        updates.approvedAt = new Date();
      } else if (updates.status === 'DISBURSED') {
        updates.disbursedAt = new Date();
      }
      
      const loan = await storage.updateLoanApplication(id, updates);
      
      if (!loan) {
        return res.status(404).json({ message: "Loan not found" });
      }
      
      res.json(loan);
    } catch (error) {
      res.status(500).json({ message: "Failed to update loan" });
    }
  });

  // Polls
  app.get("/api/polls", authenticateToken, async (req, res) => {
    try {
      const { groupId } = req.query;
      
      if (!groupId) {
        return res.status(400).json({ message: "Group ID is required" });
      }
      
      const polls = await storage.getPollsByGroup(parseInt(groupId as string));
      res.json(polls);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch polls" });
    }
  });

  app.post("/api/polls", authenticateToken, requireRole(['ADMIN', 'PRESIDENT']), async (req, res) => {
    try {
      const pollData = insertPollSchema.parse(req.body);
      const poll = await storage.createPoll(pollData);
      res.status(201).json(poll);
    } catch (error) {
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  app.post("/api/polls/:id/vote", authenticateToken, async (req, res) => {
    try {
      const pollId = parseInt(req.params.id);
      const { selectedOption } = req.body;
      const user = req.user;
      
      if (!user) {
        return res.status(401).json({ message: "User not authenticated" });
      }
      
      const member = await storage.getMemberByUserId(user.id);
      if (!member) {
        return res.status(400).json({ message: "Member not found" });
      }
      
      const vote = await storage.createPollVote({
        pollId,
        memberId: member.id,
        selectedOption,
        votedAt: new Date(),
      });
      
      res.status(201).json(vote);
    } catch (error) {
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  app.get("/api/polls/:id/votes", authenticateToken, async (req, res) => {
    try {
      const pollId = parseInt(req.params.id);
      const votes = await storage.getPollVotes(pollId);
      res.json(votes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch votes" });
    }
  });

  // SDG Impact
  app.get("/api/sdg/impact/:groupId", authenticateToken, async (req, res) => {
    try {
      const groupId = parseInt(req.params.groupId);
      const impacts = await storage.getSDGImpacts(groupId);
      res.json(impacts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch SDG impacts" });
    }
  });

  app.put("/api/sdg/impact/:groupId/:goalNumber", authenticateToken, requireRole(['ADMIN', 'PRESIDENT']), async (req, res) => {
    try {
      const groupId = parseInt(req.params.groupId);
      const goalNumber = parseInt(req.params.goalNumber);
      const updates = req.body;
      
      const impact = await storage.updateSDGImpact(groupId, goalNumber, updates);
      res.json(impact);
    } catch (error) {
      res.status(500).json({ message: "Failed to update SDG impact" });
    }
  });

  // CSR Proposals
  app.get("/api/csr", authenticateToken, async (req, res) => {
    try {
      const { groupId } = req.query;
      
      if (!groupId) {
        return res.status(400).json({ message: "Group ID is required" });
      }
      
      const proposals = await storage.getCSRProposalsByGroup(parseInt(groupId as string));
      res.json(proposals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch CSR proposals" });
    }
  });

  app.post("/api/csr", authenticateToken, async (req, res) => {
    try {
      const proposalData = insertCSRProposalSchema.parse(req.body);
      const proposal = await storage.createCSRProposal(proposalData);
      res.status(201).json(proposal);
    } catch (error) {
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  app.put("/api/csr/:id", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      if (updates.status === 'SUBMITTED') {
        updates.submittedAt = new Date();
      }
      
      const proposal = await storage.updateCSRProposal(id, updates);
      
      if (!proposal) {
        return res.status(404).json({ message: "Proposal not found" });
      }
      
      res.json(proposal);
    } catch (error) {
      res.status(500).json({ message: "Failed to update proposal" });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats/:groupId", authenticateToken, async (req, res) => {
    try {
      const groupId = parseInt(req.params.groupId);
      
      const group = await storage.getGroup(groupId);
      const members = await storage.getMembersByGroup(groupId);
      const savings = await storage.getSavingDepositsByGroup(groupId);
      const loans = await storage.getLoanApplicationsByGroup(groupId);
      const sdgImpacts = await storage.getSDGImpacts(groupId);
      
      const totalSavings = savings.reduce((sum, deposit) => sum + parseFloat(deposit.amount), 0);
      const activeLoans = loans.filter(loan => loan.status === 'DISBURSED');
      const totalLoanAmount = activeLoans.reduce((sum, loan) => sum + parseFloat(loan.amount), 0);
      const approvedMembers = members.filter(member => member.isApproved);
      const avgSDGScore = sdgImpacts.length > 0 
        ? Math.round(sdgImpacts.reduce((sum, impact) => sum + impact.impactScore, 0) / sdgImpacts.length)
        : 0;
      
      res.json({
        totalSavings,
        totalLoanAmount,
        memberCount: approvedMembers.length,
        pendingApprovals: members.length - approvedMembers.length,
        sdgScore: avgSDGScore,
        sdgGoalsImpacted: sdgImpacts.length,
        groupBalance: parseFloat(group?.totalBalance || "0"),
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Export endpoints
  app.get("/api/export/savings/:groupId", authenticateToken, async (req, res) => {
    try {
      const groupId = parseInt(req.params.groupId);
      const format = req.query.format as string || 'json';
      
      const savings = await storage.getSavingDepositsByGroup(groupId);
      
      if (format === 'csv') {
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename=savings-export.csv');
        
        // Simple CSV generation
        const csvHeader = 'Date,Member ID,Amount,Remarks\n';
        const csvData = savings.map(deposit => 
          `${deposit.depositDate},${deposit.memberId},${deposit.amount},"${deposit.remarks || ''}"`
        ).join('\n');
        
        res.send(csvHeader + csvData);
      } else {
        res.json(savings);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to export savings data" });
    }
  });

  app.get("/api/export/loans/:groupId", authenticateToken, async (req, res) => {
    try {
      const groupId = parseInt(req.params.groupId);
      const format = req.query.format as string || 'json';
      
      const loans = await storage.getLoanApplicationsByGroup(groupId);
      
      if (format === 'csv') {
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename=loans-export.csv');
        
        const csvHeader = 'Application Date,Member ID,Amount,Purpose,Status,Repayment Period\n';
        const csvData = loans.map(loan => 
          `${loan.appliedAt},${loan.memberId},${loan.amount},"${loan.purpose}",${loan.status},${loan.repaymentPeriod}`
        ).join('\n');
        
        res.send(csvHeader + csvData);
      } else {
        res.json(loans);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to export loans data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
